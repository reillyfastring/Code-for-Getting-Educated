//neccessary libraries
#include <FEHLCD.h>
#include <FEHUtility.h>
#include <time.h>
#include <math.h>
#include <FEHImages.h>

//Common variables
#define screenHeight 240
#define screenWidth 320

//Class for pictures in the game
class Image
{
private:
//public class for all images, including each level, and the right and left character image
public:
    FEHImage CharRight;    
    FEHImage CharLeft;  
    FEHImage LVL1;
    FEHImage LVL2;
    FEHImage LVL3;
    FEHImage LVL4;
    FEHImage LVL5;
    FEHImage LVL6;
    FEHImage LVL7;
    FEHImage LVL8;
    FEHImage LVL9;
    FEHImage LVL10;
    FEHImage LVL11;
    FEHImage LVL12;
    FEHImage LVL13;
    FEHImage LVL14;
    FEHImage LVL15;
}Image1;

//Prototype functions. Most of the arguments are pointers, becuase they were initialized in either the game or main function
void game(float *ptr, int *ptr1, int *ptr2, bool *ptr3, float *ptr4, int *ptr5);
void statistics(float *ptr, int *ptr1, int *ptr2, float *ptr3);
void instructions(float *ptr);
void credits(float *ptr);
void makelvl(int *ptr, float *ptr1);
void collision(float *ptr, float *ptr1, float *ptr2, float *ptr3, float *ptr4, int *ptr5, float *ptr6, float *ptr7, float *ptr8, float *ptr9, float *ptr10, int *ptr11, bool *ptr12, bool *ptr13, bool* ptr14, int* ptr15);
void drawScreen(int *ptr, float *ptr1, float *ptr2, float *ptr3, int *ptr4, float *ptr5, float *ptr6, float *ptr7, bool *ptr8, bool *ptr9);
int MapTracker(int *ptr, int *ptr1, float *ptr2, float *ptr3, float *ptr4, float *ptr5, float *ptr6, int *ptr7);
int* MatrixStorage(int);
void TextBox(int *ptr, int *ptr1, int *ptr2, float *ptr3);

//main loop that runs the menu
int main()
{  

    //declaring variables for monitering statistics
    int gameloop, *gameloopptr;
    gameloopptr = &gameloop;
    int NOS = 0;
    int maxheight = 0, *maxheightptr, *NOSptr;
    bool summittrue = false, *summittrueptr;
    float time, *timeptr;
    timeptr = &time;
    summittrueptr = &summittrue;
    maxheightptr = &maxheight; 
    NOSptr = &NOS;

    //opening all image files
    Image1.CharRight.Open("CHARACTERGAMEFEH.pic");
    Image1.CharLeft.Open("ChracterLfeftFEH.pic");
    Image1.LVL1.Open("LVL1FEH.pic");
    Image1.LVL2.Open("LVL2FEH.pic");
    Image1.LVL3.Open("LVL3FEH.pic");
    Image1.LVL4.Open("LVL4FEH.pic");
    Image1.LVL5.Open("LVL5FEH.pic");
    Image1.LVL6.Open("LVL6FEH.pic");
    Image1.LVL7.Open("LVL7FEH.pic");
    Image1.LVL8.Open("LVL8FEH.pic");
    Image1.LVL9.Open("LVL9FEH.pic");
    Image1.LVL10.Open("LVL10FEH.pic");
    Image1.LVL11.Open("LVL11FEH.pic");
    Image1.LVL12.Open("LVL12FEH.pic");
    Image1.LVL13.Open("LVL13FEH.pic");
    Image1.LVL14.Open("LVL14FEH.pic");
    Image1.LVL15.Open("LVL15FEH.pic");

    //variables for running the menu
    bool menuloop = true;
    int xadress, yadress;
    float gametrue = 0, stattrue = 0, instructtrue = 0, creditstrue = 0;
    float* gameptr = &(gametrue);
    float* statptr = &(stattrue);
    float* creditptr = &(creditstrue);
    float* instructptr = &(instructtrue);

        //uses a do while loop in order to run the game immediately
       do {
        
        //sleeps to not register frames too fast
        Sleep(.01);

        //clears screen
        LCD.Clear();

        //draws menu icons and text
        LCD.SetFontColor(GREEN);
        LCD.FillRectangle(10, 187, 300, 45);
        LCD.FillRectangle(10, 127, 300, 45);
        LCD.FillRectangle(10, 67, 300, 45);
        LCD.FillRectangle(10, 7, 300, 45);
        LCD.SetBackgroundColor(LIGHTBLUE);
        LCD.SetFontColor(WHITE);
        LCD.WriteAt("Play Game", 105, 200);
        LCD.WriteAt("Statistics", 100, 140);
        LCD.WriteAt("Instructions", 85, 80);
        LCD.WriteAt("Credits", 112, 20);

        //updates screen
        LCD.Update();

        //detects if play game is pressed
        if (LCD.Touch(&xadress, &yadress) == true) {
            if ((xadress > 10 && xadress < 310) && (yadress < 232 && yadress > 187)) {
                gametrue = 1;
                Sleep(.25);
            }
        }

        //detects if statistics is pressed
        if (LCD.Touch(&xadress, &yadress) == true) {
            if ((xadress > 10 && xadress < 310) && (yadress < 172 && yadress > 127)) {
            stattrue = 1;
            Sleep(.25);
            }
        }

        //detects if instructions is pressed
        if (LCD.Touch(&xadress, &yadress) == true) {
            if ((xadress > 10 && xadress < 310) && (yadress < 112 && yadress > 67)) {
            instructtrue = 1;
            Sleep(.25);
            }
        }

        //detects if credits is pressed
        if (LCD.Touch(&xadress, &yadress) == true) {
            if ((xadress > 10 && xadress < 310) && (yadress < 52 && yadress > 7)) {
            creditstrue = 1;
            Sleep(.25);
            }
        }

        //calls functions that run if the corresponding button is pressed
        game(gameptr, maxheightptr, NOSptr, summittrueptr, timeptr, gameloopptr);
        gametrue = 0;
        statistics(statptr, maxheightptr, NOSptr, timeptr);
        stattrue = 0;
        instructions(instructptr);
        instructtrue = 0;
        credits(creditptr);
        creditstrue = 0;

   } while (menuloop == true);
}

//Statistics menu function
void statistics(float *statptr, int *maxheightptr, int *NOSptr, float *timeptr) {
    if (*statptr == 1) {
        int t = 1, xadress, yadress;
        while (t == 1) {

            //Clears screen, writes text and boxes, and updates screen. ALso sleeps to make frames.
            LCD.Clear();
            LCD.SetFontColor(GREEN);
            LCD.FillRectangle(10, 185, 300, 45);
            LCD.SetBackgroundColor(LIGHTBLUE);
            LCD.SetFontColor(WHITE);
            LCD.WriteAt("Back", 130, 198);
            LCD.WriteAt("Max Height: ", 5, 10);
            LCD.WriteAt(*maxheightptr, 145, 10);
            LCD.WriteAt("Number of Summits: ", 5, 40);
            LCD.WriteAt(*NOSptr, 230, 40);
            LCD.WriteAt("Climb Time: ", 5, 70);
            LCD.WriteAt(*timeptr, 150, 70);
            LCD.Update();
            Sleep(.01);

            //detects if back button is pressed, and transports back to main menu
            if (LCD.Touch(&xadress, &yadress) == true) {
                if ((xadress > 10 && xadress < 310) && (yadress < 230 && yadress > 185)) {
                t = 0;
                Sleep(.25);
                }
            }
        }
    }
};

void instructions(float *instructptr) {
    if (*instructptr == 1) {
        int t = 1, xadress, yadress;
        while (t == 1) {

            //Clears screen, writes text and boxes, and updates screen. ALso sleeps to make frames.
            LCD.Clear();
            LCD.SetFontColor(GREEN);
            LCD.FillRectangle(10, 185, 300, 45);
            LCD.SetBackgroundColor(LIGHTBLUE);
            LCD.SetFontColor(WHITE);
            LCD.WriteAt("Back", 130, 198);
            LCD.WriteAt("Just get to the top. No", 15, 10);
            LCD.WriteAt("one said it would be easy.", 5, 40);
            LCD.WriteAt("Touch and hold to launch.", 10, 70);
            LCD.WriteAt("Some parts are more", 40, 100);
            LCD.WriteAt("slippery than others.", 35, 130);
            LCD.WriteAt("Don't fall!", 85, 160);
            LCD.Update();
            Sleep(.01);

            //detects if back button is pressed, and transports back to main menu
            if (LCD.Touch(&xadress, &yadress) == true) {
                if ((xadress > 10 && xadress < 310) && (yadress < 230 && yadress > 185)) {
                t = 0;
                Sleep(.25);
                }
            }
        }
    }
};

void credits(float *creditsptr) {
    if (*creditsptr == 1) {
        int t = 1, xadress, yadress;
        while (t == 1) {

            //Clears screen, writes text and boxes, and updates screen. ALso sleeps to make frames.
            LCD.Clear();
            LCD.SetFontColor(GREEN);
            LCD.FillRectangle(10, 185, 300, 45);
            LCD.SetBackgroundColor(LIGHTBLUE);
            LCD.SetFontColor(WHITE);
            LCD.WriteAt("Back", 130, 198);
            LCD.WriteAt("\"Getting Over it Lyte\" was", 5, 10);
            LCD.WriteAt("created by Reilly Fastring", 5, 40);
            LCD.WriteAt("and Cameron Arnold.", 50, 70);
            LCD.Update();
            Sleep(.01);

            //detects if back button is pressed, and transports back to main menu
            if (LCD.Touch(&xadress, &yadress) == true) {
                if ((xadress > 10 && xadress < 310) && (yadress < 230 && yadress > 185)) {
                t = 0;
                Sleep(.25);
                }
            }
        }
    }
};

//function we used to create the collision for each level. Is not active unless code is modified to do so.
void makelvl(int *mat1ptr, float *makelvlptr) {
    if (*makelvlptr == 0) {

        //clears screen and declares matrix
        LCD.Clear();
        int i = 0;
        int matrix1[1000][2], xp, yp;
        mat1ptr = &matrix1[0][0];

        //runs a while loop to display the coordinates of the mouse to the console when the mouse is held. This allows the user to draw a collision box while the map is being displayed. 
        //This is printed in a format that can be copied and pasted into a matrix. It also stops if they amount of coordinates is over the matrix limit.
        while(LCD.Touch(&xp, &yp)==true && i < 1000) {
            *(mat1ptr + i) = xp;            
            *(mat1ptr + i + 1) = yp;
            i++;
            if (xp < 321 && xp > -1 && yp > -1 && yp < 241) {
            printf("%d, %d, ", xp, yp);
            }

            //change lvl to make a lvl
            Image1.LVL15.Draw(0,0);
            Sleep(.05);
        }
        if (i == 1000) {
            *makelvlptr = 1;
            printf("done");
        }

    }

};

//Main game loop function that is activated when the button is pressed from the menu.
void game(float *gameprt, int *maxheightptr, int *NOSptr, bool *summittrueptr, float *timeptr, int *gameloopptr) {
    while (*gameprt == 1) {

        //variables for making game stop and clicking through text
        *gameloopptr = 0;
        int text = 0, *textptr;
        textptr = &text;

        //makes the game run from the menu
        float makelvl2 = 0;
        float *makelvlptr = &makelvl2;

        //declaring timer for statistics
        clock_t start = clock();
        
        //predefined variables for game
        float gravity = 0, vy = 0, vx = 0, a = 0, yi = 30, xi = 100, p = 0, fps = 164, radius = 4, totalTime = 0;
        float ballStopThreshold = 0.1, velocitydampen = 4, maxXlaunchV = 4, maxYlaunchV = 4, firstT = 0;

        //undefined variables for game
        float x_position, y_position, xposi, yposi, xposf, yposf, vxlaunch, vylaunch, sleepVar, rx, ry;
        
        //collision variables
        float speed, minN, distance, matrix2[25], f = 0;
        bool e = true, z = false, gravbool = true, TBcontinue, *TBcontinueptr, push = false, *pushptr;
        TBcontinueptr = &TBcontinue;
        pushptr = &push;

        //map should be changed to corresponding level if you want to make collision for a level
        int samecheck, img = 1, LevelTracker = 0, map = 1;

        //collision pointers
        float *xiptr, *yiptr, *vxptr, *vyptr, *radptr, *speedptr, *minNptr, *distanceptr, *mat2ptr, *fptr, maxheight;
        xiptr = &xi;
        yiptr = &yi;
        vxptr = &vx;
        vyptr = &vy;
        radptr = &radius;
        speedptr = &speed;
        minNptr = &minN;
        distanceptr = &distance;
        mat2ptr = &matrix2[0];
        fptr = &f;
        bool *eptr, *zptr, *gravboolptr, left, right, *leftptr, *rightptr;
        eptr = &e;
        zptr = &z;
        gravboolptr = &gravbool;
        leftptr = &left;
        rightptr = &right;
        int *samecheckptr, *LevelTrackerptr, *mapptr, *mat1ptr;
        samecheckptr = &samecheck;
        LevelTrackerptr = &LevelTracker;
        mapptr = &map;
        
        //making gravity constant depending on how often screen is displayed
        gravity = (1/fps)*20; //11.475
        sleepVar = 1/fps;
        
        //main while loop
        while (*gameloopptr == 0) {

            //Detects max height throughout all levels and converts it to feet
            if (*mapptr > 0 || *mapptr < 5) {
                maxheight = (screenHeight-yi)/240*4838.5;
            }
            else if (*mapptr > 4 || *mapptr < 8) {
                maxheight = (screenHeight-yi)/240*4838.5*2+4838.5*1;
            }
            else if (*mapptr > 7 || *mapptr < 10) {
                maxheight = (screenHeight-yi)/240*4838.5*3+4838.5*2;
            }
            else if (*mapptr > 9 || *mapptr < 12) {
                maxheight = (screenHeight-yi)/240*4838.5*4+4838.5*3;
            }
            else if (*mapptr > 11 || *mapptr < 14) {
                maxheight = (screenHeight-yi)/240*4838.5*5+4838.5*4;
            }
            else if (*mapptr > 13 || *mapptr <= 15) {
                maxheight = (screenHeight-yi)/240*4838.5+4838.5*5;
            }
            if (maxheight > *maxheightptr) {
                *maxheightptr = maxheight;
            }

            //detects how many times the player has summitted
            if (map == 15 && yi < 50) {
                *summittrueptr = true;
            }

            //detects if the hit to scroll button is pressed and makes the text continue
            if (LCD.Touch(&x_position, &y_position) == true) {
                if ((x_position > 240 && x_position < 321) && (y_position < 36 && y_position > 1)) {
                text++;
                Sleep(.25);
                }
            }

            //uncomment to make a lvl
            //makelvl(mat1ptr, makelvlptr);

            //clears screen
            LCD.Clear();

            //calls matrix storage function to get matrix for corresponding level
            mat1ptr = MatrixStorage(map);

            //draws all objects on screen
            drawScreen(mapptr, radptr, xiptr, yiptr, mat1ptr, speedptr, vxptr, vyptr, leftptr, rightptr);
            TextBox(mapptr, textptr, gameloopptr, gameprt);

            //uncomment to make a lvl
            ///*

            //exits game
            if (LCD.Touch(&x_position, &y_position) == true) {
                if (x_position < 5 && y_position < 5) {
                        *gameprt = 0;
                        *gameloopptr = 1;
                        *mapptr = 1;
                }
            }
            //collision
            collision(yiptr, xiptr, radptr, vxptr, vyptr, mat1ptr, speedptr, minNptr, distanceptr, mat2ptr, fptr, samecheckptr, eptr, zptr, gravboolptr, LevelTrackerptr);
            //printf("collision check, ");

            //Tracks if the game switches levels
            MapTracker(LevelTrackerptr, mapptr, vxptr, vyptr, xiptr, yiptr, speedptr, textptr);

            //calculates x and y components of speed
            ry = abs(vy);

            //makes the ball stop moving once it gets below a certain speed in both components, and near bottom of screen (so it doesnt stall when going from up to down)
            if ((ry < ballStopThreshold) && (yi >= screenHeight - 10) && gravbool == true) {
                vy = 0;
                vx = 0;
                yi = screenHeight - 6;
            }

            //keeps the ball under effects of gravity otherwise  
            else if (gravbool == true) {
            vy += gravity;
            }

            //changes position of circle by velocity for next frame
            //printf("vx: %f, vy: %f\n", vx, vy);
            yi += vy;
            xi += vx;

            //counter for if statement below making it not stall at beginning of game when both components of velocity are 0.
            p += 1;

            //if statement that detects when the player starts to click and hold mouse if the ball isn't moving and a small amount of time has passed
            if(LCD.Touch(&x_position, &y_position) == true && vy == 0 && vx == 0 && p > 15 && x_position < 240 && y_position > 36){
            
                //saves first position of mouse
                xposi = x_position;
                yposi = y_position;

                //keeps detecting position of mouse until the user stops clicking and then saves final position
                while(LCD.Touch(&x_position, &y_position) == true){
                    xposf = x_position;
                    yposf = y_position;
                }

                //logging initial and final positions for testing
                //printf("The initial coordinates were %f, %f\n", xposi, yposi);
                //printf("The final coordinates were %f, %f\n", xposf, yposf);

                //makes the velocity a factor of the distance          
                vxlaunch = ((xposi - xposf)/velocitydampen);
                vylaunch = ((yposi - yposf)/velocitydampen);

                //more statistics about recorded velocity and actual velocity
                //printf("vxlaunch: %f\n", vxlaunch);
                //printf("vylaunch: %f\n", vylaunch);
                //printf("vx before: %f\n", vx);
                //printf("vy before: %f\n", vy);

                //sets radius from original point that the velocity maxes out
                //if velocity is over max, reduce it down to max
                if(abs(vxlaunch) >= maxXlaunchV){
                    vx += (maxXlaunchV*(vxlaunch/abs(vxlaunch)));
                }

                //if not then keep it the same
                else{
                    vx += vxlaunch;
                }

                //if velocity is over max, reduce it down to max
                if(abs(vylaunch) >= maxYlaunchV){
                    vy += (maxYlaunchV*(vylaunch/abs(vylaunch)));
                }

                //if not then keep it the same
                else{
                    vy += vylaunch;
                }

                //states actual velocities being added to the ball
                //printf("vx after: %f\n", vx);
                //printf("vy after: %f\n", vy);
                //changes gravity to true and resets image booleans
                gravbool = true;
                left = false;
                right = false;
            }
            
        //uncomment to create collision for level
        //*/

        //updates screen
        LCD.Update();
        
        }

        //counting time it takes to summit
        clock_t end = clock();
        float seconds = (float)(end-start)/CLOCKS_PER_SEC;
        *timeptr = seconds;
    }

    //adds to summit level in statistics
    if(*summittrueptr == true) {
        (*NOSptr)++;
        *summittrueptr = false;
    }
}

//function that draws the screen
void drawScreen(int *mapptr, float *radptr, float *xiptr, float *yiptr, int *mat1ptr, float *speedptr, float *vxptr, float *vyptr, bool *leftptr, bool *rightptr) {
        //switch that takes a int from lvltracker and decides which background to draw
        switch (*mapptr) {
            case 1:
            Image1.LVL1.Draw(0, 0);
            break;
            case 2:
            Image1.LVL2.Draw(0, 0);
            break;
            case 3:
            Image1.LVL3.Draw(0, 0);
            break;
            case 4:
            Image1.LVL4.Draw(0, 0);
            break;
            case 5:
            Image1.LVL5.Draw(0, 0);
            break;
            case 6:
            Image1.LVL6.Draw(0, 0);
            break;
            case 7:
            Image1.LVL7.Draw(0, 0);
            break;
            case 8:
            Image1.LVL8.Draw(0, 0);
            break;
            case 9:
            Image1.LVL9.Draw(0, 0);
            break;
            case 10:
            Image1.LVL10.Draw(0, 0);
            break;
            case 11:
            Image1.LVL11.Draw(0, 0);
            break;
            case 12:
            Image1.LVL12.Draw(0, 0);
            break;
            case 13:
            Image1.LVL13.Draw(0, 0);
            break;
            case 14:
            Image1.LVL14.Draw(0, 0);
            break;
            case 15:
            Image1.LVL15.Draw(0, 0);
            break;
        }

    //declaring variables to remember which way the character is drawn when speed is 0
    bool left, right;

    //draws main collision hitbox for map and is used as an outline for the picture
    //LCD.SetFontColor(BLACK);
    //for (int i = 0 ; i<1000 ; i++) {
    //   LCD.DrawPixel(*(mat1ptr+2*i),*(mat1ptr+2*i+1));
    //}

    //draws the x in top left corner
    LCD.SetFontColor(RED);
    LCD.DrawLine(1, 6, 6, 1);
    LCD.DrawLine(1, 1, 6, 6);

    // LCD.WriteAt((int)vx, 10, 50);
    //draws the circle that is actually colliding
    //LCD.SetFontColor(GREEN);
    //LCD.FillCircle(*xiptr ,*yiptr ,*radptr);

    //checks if image moving to right and then changes character image accordingly. Also saves state
    if (*vxptr > 0){
    Image1.CharRight.Draw(*xiptr - 9 ,*yiptr-21);
    *rightptr = true;
    }

    //checks if image moving to right and then changes character image accordingly. Also saves state
    else if (*vxptr < 0) {
    Image1.CharLeft.Draw(*xiptr - 9 ,*yiptr-21);
    *leftptr = true;
    }

    //if velocity is 0, draws saved state image
    else {
        if (*rightptr == true) {
            Image1.CharRight.Draw(*xiptr - 9 ,*yiptr-21);
        }
        else if (*leftptr == true) {
            Image1.CharLeft.Draw(*xiptr - 9 ,*yiptr-21);
        }
        else {
            Image1.CharRight.Draw(*xiptr - 9 ,*yiptr-21);
        }
    }
};

//collision function
void collision(float *yiptr, float* xiptr, float* radptr, float* vxptr, float* vyptr, int* mat1ptr, float* speedptr, float *minNptr, float *distanceptr, float *mat2ptr, float *fptr, int* samecheckptr, bool* eptr, bool* zptr, bool* gravboolptr, int* LevelTrackerptr) {
    
    //collision variables
    float c, g, h, slopeavg, rise1, rise2, rise3, rise4, run1, run2, run3, run4, slope1, slope2, slope3, slope4, theta, vxf, vyf, xposprime, yposprime, xnegprime, ynegprime;
    int b, counter, counter2;
    float walldamp = 0.6;

    //calculates speed
    *speedptr = sqrt(pow(*vxptr, 2)+pow(*vyptr, 2));

    //makes g big so it can detect the lowest distance
    g = 100;

    //does the same for distance
   *distanceptr = 0;

    //calculates distance at every point and saves lowest distance. Also sets collision boolean to true
    for (int i = 0; i<1000; i++) {
        *distanceptr = sqrt(pow((*xiptr-*(mat1ptr+2*i)),2)+pow((*yiptr-*(mat1ptr+2*i+1)),2));
        if (*distanceptr < *radptr+*speedptr) {
            if (*distanceptr < g) {
            *zptr = true;
            b = i;
            g = *distanceptr;
            }
        }
    }

    //calculates 4 slopes around that collision point and averages them
    rise1 = *(mat1ptr+2*b-8+1)-*(mat1ptr+2*b+8+1);
    run1 = *(mat1ptr+2*b+8)-*(mat1ptr+2*b-8);
    slope1 = rise1/run1;
    rise2 = *(mat1ptr+2*b-10+1)-*(mat1ptr+2*b+10+1);
    run2 = *(mat1ptr+2*b+10)-*(mat1ptr+2*b-10);
    slope2 = rise2/run2;
    rise3 = *(mat1ptr+2*b-12+1)-*(mat1ptr+2*b+12+1);
    run3 = *(mat1ptr+2*b+12)-*(mat1ptr+2*b-12);
    slope3 = rise3/run3;
    rise4 = *(mat1ptr+2*b-14+1)-*(mat1ptr+2*b+14+1);
    run4 = *(mat1ptr+2*b+14)-*(mat1ptr+2*b-14);
    slope4 = rise4/run4;
    slopeavg = (slope1+slope2+slope3+slope4)/4;
    theta = atan(slopeavg);

    //collision detection for stopping the ball at a low enough speed
    if (*zptr == true && *speedptr < 1.5) {
        *vxptr = 0;
        *vyptr = 0;
        *zptr = false;

        //stops gravity so it doesn't fall through map
        *gravboolptr = false;
        *yiptr -= (*radptr)+*speedptr;
        if ((*xiptr-*(mat1ptr+2*b))>0 && *xiptr < 314) {
            *xiptr += *radptr+*speedptr;
        }
        if ((*xiptr-*(mat1ptr+2*b))<0) {
            *xiptr -= (*radptr+*speedptr);
        }
        else {
        }
    }

    //collision detection if speed isn't 0
    else if (*zptr == true) {

        //calculates realistic final x and y velocities for an initial x and y velocity and slope. Rotates the tangent line of the slope to horizontal, reverses perpendicular component, rotates back.
        xposprime = *vxptr*cos(theta)+-1*(*vyptr)*sin(theta);
        yposprime = -1*(*vxptr)*sin(theta)+-1*(*vyptr)*cos(theta);
        yposprime = yposprime*-1;
        *vxptr = (xposprime*cos(theta)-yposprime*sin(theta))*walldamp;
        *vyptr = -1*(xposprime*sin(theta)+yposprime*cos(theta))*walldamp;
        *zptr = false;

    }
    
    //double check for map collision
    if (*xiptr + *radptr > 320) {
        *xiptr = 320-*radptr;
    }

    //double check for map collision
    if (*xiptr + *radptr < 0) {
        *xiptr = 0+*radptr;
    }

    //bottom screen collision
    if (((*yiptr >= (screenHeight - *radptr)) || (*yiptr >= ((screenHeight - *radptr) - *vyptr))) && *vyptr > 0 && *speedptr != 0)  {
        *LevelTrackerptr = 1;
    }

    //top screen collision
    else if ((*yiptr <= *radptr || *yiptr <= (*radptr-*vyptr)) && (*vyptr < 0) && *speedptr != 0) {
        *LevelTrackerptr = 2;
    }

    //right screen collision
    else if (*xiptr >= (screenWidth-*radptr) || *xiptr >= (screenWidth-*radptr-*vxptr) && *vxptr > 0 && *speedptr != 0) {
        *LevelTrackerptr = 3;
    }

    //left screen collision
    else if (*xiptr <= *radptr || *xiptr <= (*radptr-*vxptr) && *vxptr < 0 && *speedptr != 0) {
        *LevelTrackerptr = 4;
    }
    else {
        *LevelTrackerptr = 0;
    }
};

//draws text for all levels
void TextBox(int *mapptr, int *textptr, int *gameloopptr, float *gameprt) {
    LCD.SetFontColor(BLACK);

    //takes in the map level and how many times the scroll button has been clicked and draws the respective text box.
    if (*mapptr == 1) {
        switch (*textptr) {
           case 0:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Today, I begin a new", 10, 172);
            LCD.WriteAt("journey alone, carving a", 10, 188);
            break;
            case 1:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("path up Everest, a silent", 10, 172);
            LCD.WriteAt("guide for future climbers", 10, 188);
            break;
        }
    }
    if (*mapptr == 2) {
        switch (*textptr) {
           case 0:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("The morning sun kisses", 10, 172);
            LCD.WriteAt("the peaks, and I lay", 10, 188);
            break;
            case 1:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("stones with hope, each", 10, 172);
            LCD.WriteAt("step a part of history.", 10, 188);
            break;
        }
    }
    if (*mapptr == 3) {
        switch (*textptr) {
           case 0:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Alone with the mountain,", 10, 172);
            LCD.WriteAt("I feel a deep bond, our", 10, 188);
            break;
            case 1:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("shared stories whispered", 10, 172);
            LCD.WriteAt("by the wind.", 10, 188);
            break;
        }
    }
    if (*mapptr == 4) {
        switch (*textptr) {
           case 0:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("The path unfolds before", 10, 172);
            LCD.WriteAt("me, a solitary line", 10, 188);
            break;
            case 1:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("between ambition and the", 10, 172);
            LCD.WriteAt("reverence of these", 10, 188);
            break;
            case 2:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("heights.", 10, 172);
            break;
        }
    }
    if (*mapptr == 6) {
        switch (*textptr) {
           case 0:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("As the day wears on, I", 10, 172);
            LCD.WriteAt("ponder the changes.", 10, 188);
            break;
            case 1:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Everest, once remote,", 10, 172);
            LCD.WriteAt("now a beacon for many.", 10, 188);
            break;
        }
    }
    if (*mapptr == 7) {
        switch (*textptr) {
           case 0:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Discarded waste mars the", 10, 172);
            LCD.WriteAt("trail, a stark reminder ", 10, 188);
            break;
            case 1:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("of the mountain's shift", 10, 172);
            LCD.WriteAt("from sacred to commercial", 10, 188);
            break;
        }
    }
    if (*mapptr == 8) {
        switch (*textptr) {
           case 0:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("I realize Everest's", 10, 172);
            LCD.WriteAt("loneliness mirrors my", 10, 188);
            break;
            case 1:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("own, a giant besieged ", 10, 172);
            LCD.WriteAt("by the footsteps of the", 10, 188);
            break;
            case 2:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("world.", 10, 172);
            break;
        }
    }
    if (*mapptr == 9) {
        switch (*textptr) {
           case 0:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("With each stone, I strive", 10, 172);
            LCD.WriteAt("to balance human", 10, 188);
            break;
            case 1:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("aspirations with the", 10, 172);
            LCD.WriteAt("dignity of this ancient", 10, 188);
            break;
            case 2:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("land.", 10, 172);
            break;
        }
    }
    if (*mapptr == 10) {
        switch (*textptr) {
           case 0:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("The stones grow heavier,", 10, 172);
            LCD.WriteAt("echoing the mountain's", 10, 188);
            break;
            case 1:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("silent grief under the", 10, 172);
            LCD.WriteAt("burden of endless", 10, 188);
            break;
            case 2:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("footsteps.", 10, 172);
            break;
        }
    }
    if (*mapptr == 11) {
        switch (*textptr) {
           case 0:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Thoughts of fellow", 10, 172);
            LCD.WriteAt("Sherpas, guardians of", 10, 188);
            break;
            case 1:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("these paths, weigh on", 10, 172);
            LCD.WriteAt("me; their quiet", 10, 188);
            break;
            case 2:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("sacrifices often unseen.", 10, 172);
            break;
        }
    }
    if (*mapptr == 13) {
        switch (*textptr) {
           case 0:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("The thin air whispers", 10, 172);
            LCD.WriteAt("tales of those who never", 10, 188);
            break;
            case 1:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("returned, their stories", 10, 172);
            LCD.WriteAt("etched in the frost.", 10, 188);
            break;
            case 2:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("I recall the faces of", 10, 172);
            LCD.WriteAt("friends now gone, their", 10, 188);
            break;
            case 3:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("laughter now just echoes", 10, 172);
            LCD.WriteAt("on the wind.", 10, 188);
            break;
        }
    }
    if (*mapptr == 14) {
        switch (*textptr) {
           case 0:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("The solitude deepens with", 10, 172);
            LCD.WriteAt("the fading light, each", 10, 188);
            break;
            case 1:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("step a tribute to those", 10, 172);
            LCD.WriteAt("who walked before. As", 10, 188);
            break;
            case 2:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("dusk embraces Everest, I", 10, 172);
            LCD.WriteAt("reflect on our role,", 10, 188);
            break;
            case 3:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("unseen architects of", 10, 172);
            LCD.WriteAt("others' dreams.", 10, 188);
            break;
        }
    }
    if (*mapptr == 15) {
        switch (*textptr) {
            case 0:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Then, in the twilight,", 10, 172);
            LCD.WriteAt("a solemn discovery: a", 10, 188);
            break;
            case 1:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("fellow Sherpa, fallen.", 10, 172);
            LCD.WriteAt("Alone, I stand by", 10, 188);
            break;
            case 2:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("him, our journeys ", 10, 172);
            LCD.WriteAt("intertwined. His silent", 10, 188);
            break;
            case 3:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("form, a poignant", 10, 172);
            LCD.WriteAt("testament to our", 10, 188);
            break;
            case 4:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("shared fate, laying", 10, 172);
            LCD.WriteAt("paths for others while", 10, 188);
            break;
            case 5:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("navigating our own", 10, 172);
            LCD.WriteAt("precarious existence.", 10, 188);
            break;
            case 6:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("In his stillness,", 10, 172);
            LCD.WriteAt("Everest's harsh truth", 10, 188);
            break;
            case 7:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("reveals itself; we", 10, 172);
            LCD.WriteAt("are but fleeting guests", 10, 188);
            break;
            case 8:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("in its eternal realm,", 10, 172);
            LCD.WriteAt("our triumphs and", 10, 188);
            break;
            case 9:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("tragedies equally", 10, 172);
            LCD.WriteAt("ephemeral. This", 10, 188);
            break;
            case 10:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("path we carve, a", 10, 172);
            LCD.WriteAt("fragile thread in", 10, 188);
            break;
            case 11:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("the vast tapestry of", 10, 172);
            LCD.WriteAt("the mountain's", 10, 188);
            break;
            case 12:
            LCD.DrawRectangle(239, 0, 80, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(240, 1, 78, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("Hit to", 240, 3);
            LCD.WriteAt("Scroll", 240, 19);
            LCD.DrawRectangle(9, 169, 302, 36);
            LCD.SetFontColor(BEIGE);
            LCD.FillRectangle(10, 170, 300, 34);
            LCD.SetFontColor(BLACK);
            LCD.WriteAt("timeless saga.", 10, 192);
            Sleep(3000);
            *gameprt = 0;
            *gameloopptr = 1;
            *mapptr = 1;
            break;
        }
    }
}

//Maptracker function that keeps track of whether the level changes for a border collision
int MapTracker(int *LevelTrackerptr, int *mapptr, float *vxptr, float *vyptr, float *xiptr, float *yiptr, float *speedptr, int *textptr) {

    //Decreases velocity if the ball collides with a wall
    float walldamp = 0.8;

    //if there are no border collisions, do nothing
    if (*LevelTrackerptr == 0) {
        return 1;
    }

    //big if else statement chain that first detects which level it is on, and then picks the respective action depending on which border has been hit and which map it is on.
    if (*mapptr == 1) {
        switch (*LevelTrackerptr) {
            case 1:
            *vyptr = (-1.0*walldamp*(*vyptr));
            *vxptr = (walldamp*(*vxptr));
            return 1;
            break;
            case 2:
            *vyptr = (-1.0*walldamp*(*vyptr));
            *vxptr = (walldamp*(*vxptr));
            return 1;
            break;
            case 3:
            *mapptr = 2;
            *xiptr = 6;
            *textptr = 0;
            return 2;
            break;
            case 4:
            *vxptr = (-1.0*walldamp*(*vxptr));
            *vyptr = (walldamp*(*vyptr));
            return 1;
            break;
        }
    }
    else if (*mapptr == 2) {
        switch (*LevelTrackerptr) {
            case 1:
            *vyptr = (-1.0*walldamp*(*vyptr));
            *vxptr = (walldamp*(*vxptr));
            return 1;
            break;
            case 2:
            *vyptr = (-1.0*walldamp*(*vyptr));
            *vxptr = (walldamp*(*vxptr));
            return 1;
            break;
            case 3:
            *mapptr = 3;
            *xiptr = 6;
            *textptr = 0;
            return 3;
            break;
            case 4:
            *mapptr = 1;
            *xiptr = 314;
            *textptr = 0;
            return 1;
            break;
        }
    }
    else if (*mapptr == 3) {
        switch (*LevelTrackerptr) {
            case 2:
            *mapptr = 5;
            *yiptr = 234;
            *textptr = 0;
            return 5;
            break;
            case 3:
            *mapptr = 4;
            *xiptr = 6;
            *textptr = 0;
            return 4;
            break;
            case 4:
            *mapptr = 2;
            *xiptr = 314;
            *textptr = 0;
            return 2;
            break;
        }
    }
    else if (*mapptr == 4) {
        switch (*LevelTrackerptr) {
            case 2:
            *mapptr = 6;
            *yiptr = 234;
            *textptr = 0;
            return 2;
            break;
            case 4:
            *mapptr = 3;
            *xiptr = 314;
            *textptr = 0;
            return 3;
            break;
        }
    }
    else if (*mapptr == 5) {
        switch (*LevelTrackerptr) {
            case 1:
            *mapptr = 3;
            *yiptr = 6;
            *textptr = 0;
            return 3;
            break;
            case 2:
            *vyptr = (-1.0*walldamp*(*vyptr));
            *vxptr = (walldamp*(*vxptr));
            return 5;
            break;
            case 3:
            *mapptr = 6;
            *xiptr = 6;
            *textptr = 0;
            return 6;
            break;
            case 4:
            *vxptr = (-1.0*walldamp*(*vxptr));
            *vyptr = (walldamp*(*vyptr));
            return 5;
            break;
        }
    }
    else if (*mapptr == 6) {
        switch (*LevelTrackerptr) {
            case 1:
            *mapptr = 4;
            *yiptr = 6;
            *textptr = 0;
            return 4;
            break;
            case 2:
            *vyptr = (-1.0*walldamp*(*vyptr));
            *vxptr = (walldamp*(*vxptr));
            return 6;
            break;
            case 3:
            *mapptr = 7;
            *xiptr = 6;
            *textptr = 0;
            return 7;
            break;
            case 4:
            *mapptr = 5;
            *xiptr = 314;
            *textptr = 0;
            return 5;
            break;
        }
    }
    else if (*mapptr == 7) {
        switch (*LevelTrackerptr) {
            case 2:
            *mapptr = 8;
            *yiptr = 234;
            *textptr = 0;
            return 8;
            break;
            case 4:
            *mapptr = 6;
            *xiptr = 314;
            *textptr = 0;
            return 6;
            break;
        }
    }
    else if (*mapptr == 8) {
        switch (*LevelTrackerptr) {
            case 1:
            *mapptr = 7;
            *yiptr = 6;
            *textptr = 0;
            return 7;
            case 2:
            *vyptr = (-1.0*walldamp*(*vyptr));
            *vxptr = (walldamp*(*vxptr));
            return 8;
            break;
            case 3:
            *mapptr = 9;
            *xiptr = 6;
            *textptr = 0;
            return 9;
            break;
            case 4:
            *vxptr = (-1.0*walldamp*(*vxptr));
            *vyptr = (walldamp*(*vyptr));
            return 8;
            break;
        }
    }
    else if (*mapptr == 9) {
        switch (*LevelTrackerptr) {
            case 2:
            *mapptr = 10;
            *yiptr = 234;
            *textptr = 0;
            return 10;
            break;
            case 4:
            *mapptr = 8;
            *xiptr = 314;
            *textptr = 0;
            return 8;
            break;
        }
    }
    else if (*mapptr == 10) {
        switch (*LevelTrackerptr) {
            case 1:
            *mapptr = 9;
            *yiptr = 6;
            *textptr = 0;
            return 9;
            case 2:
            *mapptr = 12;
            *yiptr = 234;
            *textptr = 0;
            return 12;
            break;
            case 3:
            *mapptr = 11;
            *xiptr = 6;
            *textptr = 0;
            return 11;
            break;
            case 4:
            *vxptr = (-1.0*walldamp*(*vxptr));
            *vyptr = (walldamp*(*vyptr));
            return 10;
            break;
        }
    }
    else if (*mapptr == 11) {
        switch (*LevelTrackerptr) {
            case 2:
            *mapptr = 13;
            *yiptr = 234;
            *textptr = 0;
            return 13;
            break;
            case 4:
            *mapptr = 10;
            *xiptr = 314;
            *textptr = 0;
            return 10;
            break;
        }
    }
    else if (*mapptr == 12) {
        switch (*LevelTrackerptr) {
            case 1:
            *mapptr = 10;
            *yiptr = 6;
            *textptr = 0;
            return 10;
            break;
            case 2:
            *vyptr = (-1.0*walldamp*(*vyptr));
            *vxptr = (walldamp*(*vxptr));
            return 12;
            break;
            case 3:
            *mapptr = 13;
            *xiptr = 6;
            *textptr = 0;
            return 13;
            break;
            case 4:
            *vxptr = (-1.0*walldamp*(*vxptr));
            *vyptr = (walldamp*(*vyptr));
            return 12;
            break;
        }
    }
    else if (*mapptr == 13) {
        switch (*LevelTrackerptr) {
            case 1:
            *mapptr = 11;
            *yiptr = 6;
            *textptr = 0;
            return 11;
            break;
            case 2:
            *mapptr = 14;
            *yiptr = 234;
            *textptr = 0;
            return 14;
            break;
            case 4:
            *mapptr = 12;
            *xiptr = 314;
            *textptr = 0;
            return 12;
            break;
        }
    }
    else if (*mapptr == 14) {
        switch (*LevelTrackerptr) {
            case 1:
            *mapptr = 13;
            *yiptr = 6;
            *textptr = 0;
            return 13;
            break;
            case 2:
            *vyptr = (-1.0*walldamp*(*vyptr));
            *vxptr = (walldamp*(*vxptr));
            return 14;
            break;
            case 3:
            *mapptr = 15;
            *xiptr = 6;
            *textptr = 0;
            return 15;
            break;
            case 4:
            *vxptr = (-1.0*walldamp*(*vxptr));
            *vyptr = (walldamp*(*vyptr));
            return 14;
            break;
        }
    }
    else if (*mapptr == 15) {
        switch (*LevelTrackerptr) {
            case 2:
            *vyptr = (-1.0*walldamp*(*vyptr));
            *vxptr = (walldamp*(*vxptr));
            return 15;
            break;
            case 4:
            *mapptr = 14;
            *xiptr = 314;
            *textptr = 0;
            return 14;
            break;
        }
    }
    
    //resets level tracker
    *LevelTrackerptr = 0;
}

//main matrix storage function. Takes in level that it should be on from maptracker, and returns an adress of the correct collision matrix
int* MatrixStorage(int map) {

    //declaring all matrix varibles
    int *matrix1, *matrix2, *matrix3, *matrix4, *matrix5, *matrix6, *matrix7, *matrix8, *matrix9, *matrix10, *matrix11, *matrix12, *matrix13, *matrix14, *matrix15;

    //declarations of all the level collision matrixes. Very important to make these static so that the memory isn't changed/declared every time the code runs.
    static int mat1[1000][2] = {
        0, 150, 0, 150, 0, 150, 0, 149, 0, 149, 0, 149, 0, 149, 0, 149, 1, 148, 2, 148, 2, 148, 3, 148, 4, 148, 4, 148, 5, 148, 6, 148, 7, 148, 7, 148, 8, 148, 9, 148, 10, 148, 11, 148, 11, 148, 12, 149, 13, 149, 14, 149, 15, 149, 16, 150, 17, 150, 19, 150, 20, 151, 21, 151, 22, 151, 23, 152, 24, 152, 25, 152, 27, 152, 
        28, 152, 29, 152, 29, 152, 30, 153, 31, 153, 33, 153, 35, 153, 36, 153, 37, 153, 38, 154, 39, 154, 40, 155, 42, 155, 44, 155, 47, 156, 49, 156, 51, 157, 53, 157, 54, 157, 54, 158, 55, 158, 56, 158, 57, 158, 58, 158, 60, 158, 62, 158, 63, 158, 65, 159, 66, 159, 67, 159, 68, 159, 69, 159, 71, 159, 73, 159, 74, 159, 74, 159, 75, 159, 76, 159, 77, 159, 78, 159, 79, 159, 79, 159, 80, 160, 81, 160, 81, 160, 82, 160, 83, 160, 84, 160, 86, 160, 87, 160, 88, 160, 89, 160, 91, 159, 92, 159, 94, 159, 95, 159, 96, 159, 97, 159, 98, 159, 99, 159, 101, 159, 102, 159, 103, 159, 104, 159, 105, 159, 106, 159, 107, 159, 108, 159, 110, 159, 110, 159, 111, 159, 112, 159, 113, 159, 115, 159, 117, 158, 119, 158, 120, 158, 122, 158, 123, 158, 124, 158, 126, 157, 127, 157, 128, 157, 129, 157, 129, 157, 129, 157, 130, 157, 131, 156, 132, 156, 133, 156, 134, 156, 135, 156, 136, 156, 137, 155, 139, 155, 140, 155, 141, 154, 142, 154, 142, 154, 143, 154, 144, 154, 145, 154, 146, 154, 147, 153, 148, 153, 149, 152, 151, 152, 152, 152, 152, 152, 153, 151, 154, 151, 156, 151, 157, 150, 157, 150, 157, 150, 157, 150, 157, 150, 157, 150, 158, 150, 160, 150, 160, 150, 160, 149, 161, 149, 162, 149, 163, 149, 164, 149, 164, 149, 165, 149, 166, 149, 167, 149, 168, 148, 169, 148, 169, 148, 170, 148, 171, 148, 172, 148, 172, 148, 173, 148, 174, 148, 175, 148, 176, 148, 177, 148, 178, 148, 179, 148, 180, 148, 181, 147, 183, 147, 183, 147, 185, 147, 186, 147, 187, 147, 189, 147, 190, 147, 192, 147, 194, 147, 195, 147, 197, 147, 198, 147, 199, 147, 200, 148, 202, 148, 203, 148, 204, 
        148, 205, 148, 206, 148, 208, 148, 209, 148, 210, 148, 212, 148, 213, 148, 214, 148, 215, 148, 216, 148, 217, 148, 218, 148, 219, 148, 221, 148, 222, 148, 223, 148, 224, 148, 226, 148, 227, 148, 228, 148, 229, 148, 230, 148, 232, 148, 233, 149, 234, 149, 235, 149, 236, 149, 238, 150, 239, 150, 240, 150, 241, 150, 242, 150, 243, 150, 244, 150, 245, 150, 246, 150, 247, 151, 249, 151, 250, 151, 251, 151, 253, 151, 254, 151, 255, 151, 256, 151, 257, 151, 258, 152, 259, 152, 260, 152, 261, 152, 262, 152, 264, 152, 265, 152, 266, 152, 267, 152, 268, 153, 268, 153, 269, 153, 271, 153, 272, 153, 273, 153, 275, 154, 276, 154, 277, 154, 277, 154, 279, 154, 280, 154, 281, 154, 283, 154, 284, 154, 284, 154, 284, 154, 285, 154, 287, 154, 288, 154, 290, 154, 291, 154, 292, 154, 293, 154, 294, 154, 295, 153, 295, 153, 296, 153, 297, 153, 298, 153, 298, 153, 299, 153, 299, 153, 300, 153, 301, 153, 301, 153, 302, 153, 303, 153, 303, 153, 305, 153, 306, 153, 307, 153, 308, 153, 309, 153, 310, 153, 311, 153, 312, 153, 314, 153, 314, 153, 315, 153, 316, 153, 317, 153, 318, 153, 319, 153, 319, 153, 320, 153, 320, 153
     };
     static int mat2[1000][2] = {
        0, 152, 0, 152, 0, 152, 0, 152, 1, 152, 1, 152, 2, 152, 2, 152, 3, 152, 3, 152, 4, 152, 4, 152, 5, 152, 6, 152, 7, 152, 8, 152, 9, 151, 10, 151, 10, 151, 11, 151, 12, 151, 13, 151, 14, 151, 14, 151, 15, 151, 16, 151, 17, 151, 18, 151, 19, 151, 20, 151, 20, 151, 21, 151, 22, 151, 23, 151, 24, 151, 25, 151, 26, 151, 27, 151, 28, 151, 29, 151, 30, 151, 31, 151, 32, 152, 33, 152, 34, 152, 35, 152, 36, 152, 36, 152, 37, 152, 39, 152, 40, 152, 41, 152, 42, 152, 43, 152, 43, 152, 44, 152, 46, 153, 47, 153, 48, 154, 48, 154, 49, 155, 50, 155, 50, 156, 51, 156, 52, 157, 53, 157, 54, 158, 55, 158, 55, 159, 56, 159, 57, 160, 57, 
        160, 58, 161, 59, 161, 59, 162, 60, 162, 61, 163, 61, 163, 62, 164, 63, 164, 63, 164, 64, 164, 65, 165, 65, 165, 66, 165, 67, 165, 67, 165, 68, 165, 69, 165, 70, 165, 71, 165, 72, 165, 72, 165, 73, 165, 74, 164, 75, 164, 76, 164, 77, 164, 77, 164, 78, 164, 79, 164, 80, 164, 81, 164, 82, 164, 83, 164, 84, 163, 85, 163, 86, 163, 87, 163, 88, 162, 89, 162, 90, 161, 90, 161, 91, 160, 91, 159, 92, 159, 92, 159, 93, 158, 94, 158, 94, 157, 95, 157, 96, 156, 96, 155, 97, 155, 98, 154, 98, 154, 99, 153, 100, 153, 100, 152, 101, 151, 101, 150, 101, 150, 102, 149, 102, 148, 102, 147, 103, 147, 103, 146, 103, 146, 104, 145, 104, 144, 105, 143, 105, 143, 106, 142, 106, 142, 106, 141, 106, 141, 107, 140, 107, 140, 107, 139, 108, 138, 109, 138, 109, 137, 110, 137, 110, 136, 111, 136, 112, 136, 112, 135, 113, 135, 113, 135, 114, 134, 115, 134, 116, 134, 117, 133, 118, 133, 119, 133, 119, 132, 120, 132, 121, 132, 121, 131, 122, 131, 122, 131, 123, 131, 124, 131, 125, 131, 125, 132, 126, 132, 126, 132, 127, 133, 127, 133, 128, 133, 128, 134, 129, 134, 129, 134, 130, 134, 130, 134, 130, 134, 130, 134, 131, 134, 131, 134, 132, 134, 133, 133, 133, 133, 133, 132, 133, 132, 133, 131, 134, 131, 134, 130, 134, 130, 134, 130, 135, 130, 135, 129, 135, 129, 135, 129, 136, 129, 136, 129, 137, 130, 138, 130, 138, 130, 139, 131, 139, 131, 139, 132, 140, 132, 140, 133, 141, 133, 141, 134, 141, 134, 142, 135, 142, 135, 143, 136, 143, 136, 144, 137, 144, 137, 144, 138, 145, 138, 145, 139, 146, 139, 146, 140, 147, 140, 147, 141, 148, 141, 148, 142, 149, 142, 149, 143, 149, 
        144, 150, 144, 151, 143, 151, 143, 151, 143, 152, 143, 152, 142, 152, 142, 153, 141, 153, 141, 153, 140, 154, 140, 154, 139, 155, 139, 155, 138, 156, 138, 156, 137, 156, 137, 157, 136, 157, 135, 157, 135, 158, 134, 159, 133, 159, 132, 160, 132, 160, 131, 160, 131, 161, 130, 162, 130, 162, 129, 162, 128, 163, 127, 163, 127, 163, 126, 164, 125, 164, 125, 164, 124, 164, 123, 165, 122, 165, 122, 166, 121, 166, 120, 166, 120, 167, 120, 167, 119, 168, 119, 168, 118, 169, 117, 169, 117, 169, 116, 170, 116, 170, 115, 170, 115, 171, 114, 171, 114, 171, 113, 172, 113, 172, 113, 172, 112, 173, 112, 173, 111, 173, 110, 174, 110, 174, 109, 174, 108, 175, 108, 175, 107, 175, 106, 176, 106, 176, 105, 177, 104, 177, 103, 178, 103, 178, 102, 179, 102, 179, 102, 179, 101, 179, 101, 179, 101, 180, 101, 181, 101, 181, 100, 182, 100, 182, 100, 183, 100, 184, 100, 185, 100, 186, 100, 187, 100, 188, 100, 188, 100, 189, 100, 190, 100, 190, 100, 191, 100, 192, 100, 193, 100, 193, 101, 193, 101, 193, 102, 193, 102, 193, 103, 193, 104, 193, 105, 194, 106, 194, 107, 194, 107, 194, 108, 195, 108, 195, 109, 195, 110, 196, 110, 196, 111, 197, 111, 197, 111, 197, 112, 198, 112, 198, 113, 198, 114, 198, 115, 198, 116, 198, 117, 198, 117, 198, 118, 199, 119, 199, 120, 199, 121, 200, 122, 200, 123, 201, 123, 201, 124, 201, 125, 201, 126, 201, 127, 201, 127, 202, 128, 202, 129, 202, 130, 202, 131, 202, 132, 202, 133, 202, 134, 202, 134, 201, 135, 201, 136, 201, 137, 201, 138, 201, 139, 201, 139, 201, 140, 201, 141, 201, 142, 201, 143, 201, 144, 201, 145, 201, 146, 201, 147, 
        202, 148, 202, 149, 202, 149, 202, 150, 203, 151, 203, 151, 203, 152, 203, 153, 203, 153, 204, 155, 204, 156, 204, 157, 204, 158, 204, 159, 204, 160, 204, 161, 204, 162, 204, 162, 204, 163, 204, 163, 204, 164, 205, 164, 205, 165, 206, 165, 207, 165, 207, 165, 208, 165, 209, 164, 210, 164, 211, 164, 212, 164, 213, 163, 214, 163, 214, 163, 215, 162, 216, 162, 216, 161, 217, 160, 217, 159, 218, 159, 219, 158, 219, 157, 220, 157, 221, 156, 222, 155, 222, 155, 223, 154, 223, 154, 224, 153, 224, 153, 225, 152, 225, 151, 225, 151, 226, 150, 226, 149, 226, 149, 227, 148, 227, 147, 228, 147, 228, 146, 229, 145, 229, 144, 230, 143, 230, 142, 231, 142, 231, 141, 231, 141, 232, 141, 232, 141, 233, 141, 233, 140, 234, 140, 235, 140, 235, 140, 236, 140, 236, 140, 237, 140, 238, 140, 238, 140, 238, 140, 236, 139, 236, 139, 236, 139, 237, 140, 238, 140, 238, 140, 239, 140, 240, 140, 241, 141, 242, 141, 243, 141, 244, 141, 246, 141, 248, 141, 249, 141, 250, 141, 251, 141, 252, 141, 253, 141, 254, 141, 255, 141, 256, 140, 256, 140, 257, 140, 258, 140, 258, 140, 259, 140, 260, 140, 262, 140, 263, 140, 263, 140, 264, 140, 265, 140, 266, 141, 267, 141, 267, 141, 268, 141, 268, 142, 269, 142, 269, 142, 270, 143, 270, 143, 270, 144, 271, 144, 271, 144, 272, 145, 272, 145, 273, 146, 274, 147, 275, 147, 276, 148, 276, 148, 277, 148, 278, 148, 279, 148, 280, 147, 281, 147, 281, 146, 282, 146, 282, 146, 283, 145, 283, 145, 284, 144, 284, 144, 285, 143, 285, 143, 285, 142, 286, 141, 286, 141, 286, 141, 287, 141, 287, 141, 288, 140, 289, 140, 290, 140, 291, 140, 292, 
        140, 292, 139, 293, 139, 294, 139, 295, 138, 296, 138, 297, 137, 298, 137, 299, 136, 300, 136, 300, 135, 301, 135, 302, 134, 302, 134, 303, 133, 303, 133, 304, 132, 304, 132, 304, 131, 305, 131, 306, 130, 306, 130, 306, 129, 307, 129, 307, 128, 308, 127, 308, 127, 308, 127, 309, 126, 309, 126, 309, 125, 309, 125, 309, 125, 309, 125, 310, 125, 310, 125, 310, 125, 311, 125, 311, 125, 311, 125, 312, 125, 312, 124, 313, 124, 314, 124, 314, 124, 315, 124, 316, 124, 316, 124, 316, 124, 317, 124, 317, 124, 317, 124, 318, 124, 318, 124, 318, 124, 318, 124, 318, 124, 318, 124, 318, 124, 318, 124, 318, 124, 318, 124, 319, 124, 319, 124, 319, 124, 319, 124, 319, 124, 319, 124, 319, 124    };
     static int mat3[1000][2] = {
        0, 123, 0, 123, 1, 123, 2, 123, 3, 123, 4, 123, 4, 123, 5, 123, 7, 123, 8, 122, 9, 122, 9, 122, 9, 122, 9, 122, 9, 122, 9, 122, 10, 123, 10, 124, 12, 125, 13, 126, 14, 127, 15, 128, 15, 128, 15, 128, 15, 129, 15, 129, 16, 130, 17, 131, 19, 133, 21, 134, 22, 135, 23, 135, 25, 136, 26, 136, 27, 137, 28, 137, 30, 138, 32, 138, 33, 139, 33, 139, 33, 139, 34, 140, 35, 140, 36, 140, 36, 141, 36, 141, 37, 142, 37, 143, 38, 145, 40, 146, 41, 146, 42, 147, 44, 147, 45, 146, 47, 145, 48, 144, 49, 144, 50, 143, 50, 142, 51, 141, 51, 140, 51, 140, 52, 139, 54, 139, 55, 139, 56, 139, 58, 139, 59, 139, 60, 139, 62, 139, 63, 138, 65, 138, 65, 138, 67, 138, 69, 138, 72, 138, 73, 138, 74, 138, 75, 138, 77, 138, 78, 138, 80, 138, 80, 138, 81, 138, 82, 139, 83, 139, 83, 139, 83, 139, 84, 139, 84, 138, 84, 138, 85, 138, 85, 138, 86, 138, 87, 139, 88, 139, 88, 140, 89, 140, 90, 142, 91, 142, 91, 143, 91, 143, 92, 144, 92, 145, 93, 145, 93, 146, 94, 147, 95, 149, 96, 150, 97, 151, 97, 151, 98, 152, 98, 153, 99, 154, 100, 154, 101, 155, 101, 156, 102, 157, 103, 158, 103, 158, 104, 159, 104, 160, 105, 161, 106, 162, 107, 162, 107, 163, 108, 163, 109, 164, 109, 164, 110, 165, 111, 166, 112, 166, 114, 166, 116, 166, 117, 166, 118, 166, 120, 166, 121, 165, 122, 163, 122, 162, 123, 161, 124, 160, 125, 160, 126, 159, 127, 159, 127, 158, 128, 157, 129, 156, 129, 156, 129, 155, 130, 155, 130, 154, 131, 153, 131, 153, 132, 152, 132, 151, 133, 150, 133, 150, 134, 149, 135, 148, 136, 148, 136, 147, 137, 147, 137, 146, 138, 146, 138, 145, 139, 144, 139, 144, 139, 143, 139, 
        142, 140, 141, 140, 140, 141, 139, 142, 138, 143, 137, 143, 136, 144, 135, 145, 134, 145, 133, 146, 132, 147, 131, 147, 130, 148, 129, 148, 128, 149, 128, 150, 127, 151, 127, 151, 127, 153, 127, 154, 127, 154, 126, 155, 125, 156, 124, 157, 123, 159, 122, 160, 121, 160, 120, 161, 119, 162, 118, 163, 117, 164, 116, 164, 115, 165, 114, 165, 113, 166, 112, 167, 110, 167, 109, 168, 108, 168, 107, 169, 106, 169, 104, 170, 103, 171, 102, 172, 101, 173, 99, 174, 98, 174, 97, 175, 96, 175, 95, 176, 94, 177, 93, 177, 92, 178, 91, 179, 90, 179, 89, 180, 89, 180, 88, 181, 87, 182, 86, 182, 84, 183, 83, 183, 82, 184, 82, 184, 82, 184, 81, 185, 81, 186, 81, 186, 81, 187, 82, 188, 82, 189, 83, 189, 83, 190, 84, 191, 85, 192, 86, 193, 86, 193, 86, 195, 86, 196, 86, 197, 85, 198, 84, 198, 84, 199, 83, 200, 83, 201, 82, 203, 82, 204, 82, 206, 82, 207, 82, 207, 82, 208, 83, 209, 84, 210, 86, 210, 87, 211, 88, 211, 89, 211, 91, 212, 92, 212, 93, 213, 93, 214, 93, 215, 93, 216, 93, 216, 92, 216, 91, 216, 90, 216, 90, 216, 89, 217, 88, 218, 87, 220, 86, 221, 86, 224, 85, 225, 85, 225, 84, 226, 83, 227, 83, 229, 82, 231, 81, 233, 81, 233, 80, 234, 80, 235, 79, 236, 78, 237, 77, 238, 75, 238, 74, 239, 73, 239, 72, 240, 70, 240, 69, 240, 67, 241, 65, 242, 64, 242, 63, 243, 62, 243, 61, 244, 60, 244, 58, 245, 57, 245, 55, 246, 54, 247, 53, 247, 52, 248, 51, 248, 50, 248, 49, 249, 48, 249, 47, 249, 47, 249, 46, 249, 45, 249, 44, 250, 42, 250, 41, 250, 40, 251, 39, 251, 39, 252, 38, 252, 37, 253, 36, 254, 36, 255, 35, 256, 35, 256, 35, 257, 34, 258, 34, 260, 34, 261, 34, 261, 34, 263, 34, 264, 35, 265, 35, 266, 36, 268, 37, 268, 38, 270, 39, 270, 40, 271, 41, 272, 42, 272, 43, 273, 44, 274, 45, 274, 46, 275, 47, 276, 48, 276, 48, 277, 49, 277, 50, 278, 51, 279, 52, 280, 53, 280, 53, 281, 55, 282, 55, 282, 56, 283, 57, 283, 59, 284, 60, 284, 61, 285, 61, 285, 62, 286, 63, 287, 64, 288, 65, 288, 66, 289, 67, 289, 67, 290, 68, 290, 69, 291, 70, 292, 71, 292, 73, 293, 74, 293, 75, 294, 75, 295, 77, 295, 78, 296, 79, 297, 80, 297, 81, 298, 82, 298, 83, 299, 85, 300, 87, 301, 88, 301, 88, 302, 89, 302, 90, 303, 91, 304, 92, 305, 94, 305, 95, 306, 96, 306, 96, 307, 98, 307, 98, 307, 99, 
        307, 99, 307, 99, 307, 99, 307, 99, 308, 99, 308, 99, 309, 99, 309, 99, 310, 99, 310, 99, 311, 99, 312, 99, 312, 99, 313, 99, 313, 99, 314, 99, 315, 99, 315, 99, 317, 99, 317, 99, 317, 99, 318, 99, 319, 99, 319, 99, 320, 99, 320, 99, 320, 99
    };
     static int mat4[1000][2] = {
        0, 101, 0, 101, 0, 101, 0, 101, 0, 101, 1, 101, 2, 101, 3, 101, 4, 100, 6, 100, 9, 99, 10, 99, 10, 99, 10, 99, 10, 99, 10, 99, 11, 99, 11, 99, 12, 99, 13, 99, 14, 99, 14, 99, 14, 99, 14, 98, 14, 97, 14, 96, 14, 95, 15, 94, 15, 93, 15, 93, 16, 92, 16, 91, 16, 89, 16, 88, 16, 87, 17, 86, 17, 85, 17, 84, 17, 83, 17, 81, 18, 80, 18, 78, 18, 76, 18, 75, 19, 73, 19, 72, 20, 71, 20, 69, 20, 68, 20, 67, 21, 66, 21, 65, 21, 64, 21, 63, 21, 63, 21, 63, 22, 62, 22, 61, 22, 61, 22, 61, 23, 61, 24, 61, 25, 60, 26, 60, 27, 60, 28, 60, 31, 59, 31, 59, 31, 59, 31, 59, 31, 58, 31, 58, 31, 57, 31, 56, 32, 55, 32, 54, 32, 54, 32, 53, 33, 53, 33, 51, 34, 50, 34, 49, 34, 48, 35, 47, 35, 46, 36, 45, 36, 44, 37, 42, 38, 41, 38, 40, 38, 40, 38, 39, 39, 38, 40, 36, 40, 36, 40, 35, 41, 35, 41, 34, 41, 34, 41, 34, 41, 34, 42, 34, 43, 34, 43, 34, 44, 34, 48, 34, 50, 34, 51, 33, 51, 33, 52, 33, 52, 33, 53, 33, 53, 33, 54, 32, 55, 32, 56, 31, 56, 31, 56, 
        31, 57, 31, 58, 31, 59, 31, 59, 31, 59, 31, 60, 31, 61, 31, 62, 31, 63, 31, 63, 31, 63, 31, 64, 31, 64, 31, 64, 31, 64, 31, 64, 31, 64, 31, 64, 31, 65, 30, 66, 29, 66, 28, 66, 28, 67, 27, 67, 26, 67, 24, 68, 23, 68, 22, 69, 21, 69, 19, 70, 18, 70, 17, 70, 16, 70, 16, 70, 15, 71, 14, 71, 13, 71, 12, 72, 11, 72, 10, 72, 9, 72, 9, 72, 8, 72, 7, 72, 5, 73, 4, 73, 3, 73, 3, 73, 3, 73, 3, 73, 2, 73, 1, 73, 0, 73, 0, 73, 0, 73, 0, 73, 0, 73, 0, 73, 0, 74, 0, 74, 0, 74, 0, 74, 0, 74, 0
    };
     static int mat5[1000][2] = {
    };
     static int mat6[1000][2] = {
        70, 239, 70, 239, 70, 239, 70, 239, 70, 238, 71, 238, 72, 237, 72, 236, 73, 236, 73, 235, 73, 235, 73, 234, 74, 233, 74, 232, 74, 232, 74, 231, 74, 231, 75, 230, 75, 229, 75, 228, 76, 227, 76, 226, 76, 225, 76, 224, 76, 223, 77, 221, 77, 220, 77, 219, 77, 218, 78, 218, 79, 216, 79, 215, 79, 215, 80, 213, 81, 212, 82, 211, 83, 211, 84, 211, 86, 210, 89, 210, 90, 210, 92, 209, 93, 209, 93, 209, 93, 209, 94, 209, 95, 208, 95, 208, 95, 207, 96, 206, 96, 205, 97, 203, 97, 201, 98, 199, 98, 198, 99, 196, 99, 195, 99, 193, 100, 191, 100, 190, 100, 188, 100, 186, 101, 184, 101, 182, 101, 180, 102, 179, 102, 177, 103, 175, 104, 173, 104, 171, 105, 169, 105, 166, 106, 164, 107, 162, 107, 159, 108, 157, 109, 155, 109, 154, 109, 153, 109, 152, 109, 151, 109, 150, 109, 149, 109, 148, 110, 148, 111, 148, 112, 147, 112, 146, 112, 146, 113, 145, 113, 144, 114, 144, 115, 144, 117, 143, 119, 143, 121, 142, 122, 142, 123, 142, 123, 141, 124, 141, 125, 140, 126, 139, 127, 138, 127, 138, 127, 138, 128, 137, 128, 137, 129, 136, 129, 136, 130, 135, 131, 134, 131, 133, 131, 132, 132, 131, 132, 130, 133, 129, 133, 128, 134, 126, 135, 125, 135, 124, 136, 122, 136, 121, 137, 120, 137, 118, 138, 117, 138, 116, 139, 115, 139, 114, 140, 112, 140, 112, 140, 111, 
        141, 110, 141, 109, 141, 108, 142, 107, 142, 106, 142, 106, 142, 105, 142, 104, 142, 103, 142, 102, 143, 101, 143, 101, 143, 100, 144, 100, 145, 100, 145, 99, 146, 99, 148, 99, 149, 99, 152, 99, 153, 99, 153, 99, 154, 99, 155, 100, 156, 100, 158, 101, 158, 102, 159, 102, 160, 103, 160, 103, 160, 103, 161, 103, 162, 102, 162, 102, 162, 101, 162, 100, 162, 99, 162, 99, 163, 99, 163, 99, 164, 98, 164, 98, 165, 98, 166, 98, 168, 99, 168, 99, 169, 99, 169, 99, 169, 99, 170, 101, 171, 103, 171, 104, 172, 106, 173, 107, 173, 108, 174, 108, 174, 109, 175, 110, 176, 110, 176, 111, 177, 112, 178, 114, 179, 115, 179, 116, 180, 117, 181, 118, 182, 120, 182, 122, 183, 123, 183, 124, 184, 125, 184, 125, 185, 126, 185, 128, 186, 129, 187, 130, 188, 132, 189, 133, 189, 134, 190, 136, 191, 137, 192, 138, 193, 139, 193, 140, 194, 141, 195, 141, 196, 142, 196, 142, 197, 143, 197, 144, 198, 144, 198, 144, 199, 144, 201, 144, 202, 144, 204, 144, 
        205, 144, 205, 144, 205, 144, 205, 144, 205, 145, 205, 146, 206, 148, 207, 149, 208, 151, 209, 152, 210, 153, 211, 154, 212, 156, 214, 157, 214, 157, 214, 157, 214, 156, 214, 155, 214, 153, 214, 151, 214, 149, 214, 148, 214, 146, 214, 144, 215, 142, 215, 140, 215, 138, 216, 137, 216, 135, 217, 134, 217, 133, 217, 132, 218, 131, 218, 131, 218, 130, 219, 129, 220, 128, 221, 127, 221, 127, 222, 127, 223, 126, 224, 125, 225, 124, 226, 124, 228, 123, 229, 122, 230, 121, 232, 121, 234, 120, 235, 119, 236, 119, 237, 118, 237, 118, 238, 117, 238, 116, 239, 113, 240, 112, 240, 110, 241, 108, 242, 106, 243, 104, 243, 103, 244, 102, 244, 100, 245, 99, 246, 98, 246, 97, 246, 96, 247, 95, 248, 93, 248, 92, 249, 91, 249, 90, 249, 89, 249, 89, 249, 88, 250, 86, 250, 85, 250, 84, 251, 83, 251, 83, 252, 82, 252, 82, 253, 81, 253, 81, 254, 81, 255, 81, 256, 80, 257, 80, 258, 80, 259, 80, 260, 80, 261, 80, 262, 80, 264, 80, 265, 80, 265, 80, 266, 80, 267, 80, 268, 80, 268, 80, 269, 80, 270, 80, 270, 80, 271, 79, 271, 79, 272, 79, 273, 78, 273, 78, 273, 78, 274, 78, 275, 78, 275, 79, 276, 79, 277, 79, 277, 79, 278, 80, 279, 82, 280, 83, 280, 84, 280, 85, 281, 86, 281, 87, 282, 88, 283, 89, 284, 90, 284, 92, 285, 93, 286, 95, 287, 97, 288, 98, 289, 100, 290, 101, 291, 103, 292, 104, 292, 105, 293, 106, 294, 107, 295, 109, 295, 110, 296, 111, 297, 113, 298, 114, 298, 115, 299, 116, 300, 117, 301, 118, 302, 120, 303, 121, 304, 122, 304, 123, 305, 124, 306, 125, 306, 126, 307, 126, 307, 126, 307, 126, 307, 126, 307, 126, 307, 126, 308, 126, 308, 126, 308, 126, 309, 126, 309, 126, 310, 126, 311, 126, 312, 126, 313, 126, 314, 126, 315, 125, 316, 125, 317, 125, 318, 125, 319, 125, 319, 125, 319, 125, 319, 125
    };
     static int  mat7[1000][2] = {
        0, 125, 0, 125, 0, 125, 0, 125, 1, 125, 2, 125, 3, 125, 4, 125, 6, 125, 7, 125, 8, 125, 9, 125, 10, 125, 11, 125, 12, 125, 13, 125, 14, 124, 15, 124, 16, 124, 16, 124, 17, 124, 17, 124, 17, 124, 18, 123, 18, 122, 19, 122, 19, 121, 20, 121, 21, 120, 21, 119, 22, 118, 23, 117, 24, 115, 24, 114, 24, 113, 25, 112, 25, 112, 26, 111, 26, 110, 27, 110, 27, 109, 28, 108, 28, 107, 29, 106, 30, 105, 30, 105, 30, 105, 30, 104, 31, 103, 31, 102, 32, 101, 32, 100, 32, 99, 33, 98, 33, 97, 33, 96, 34, 95, 34, 94, 34, 94, 35, 93, 35, 92, 36, 91, 36, 90, 37, 89, 37, 88, 38, 87, 38, 86, 39, 85, 39, 84, 39, 83, 40, 81, 41, 80, 41, 78, 42, 77, 42, 76, 43, 75, 43, 74, 43, 73, 44, 72, 44, 71, 45, 71, 45, 70, 46, 69, 46, 68, 47, 67, 48, 66, 48, 65, 49, 63, 49, 62, 50, 61, 50, 60, 51, 60, 51, 59, 51, 58, 52, 58, 52, 57, 53, 57, 53, 57, 53, 56, 53, 56, 54, 55, 54, 55, 54, 54, 54, 54, 55, 53, 55, 53, 56, 52, 57, 52, 58, 51, 59, 51, 61, 51, 63, 51, 64, 51, 64, 51, 65, 52, 65, 52, 65, 52, 66, 53, 66, 53, 67, 53, 68, 53, 70, 53, 72, 54, 73, 54, 75, 54, 76, 54, 78, 54, 79, 55, 81, 55, 82, 55, 83, 56, 84, 56, 84, 56, 85, 56, 86, 56, 87, 57, 88, 57, 90, 57, 90, 57, 91, 58, 91, 59, 91, 59, 91, 60, 92, 62, 92, 63, 93, 63, 93, 64, 93, 65, 94, 66, 94, 67, 95, 69, 96, 
        70, 97, 71, 98, 71, 98, 72, 98, 73, 98, 73, 99, 74, 100, 76, 100, 77, 101, 78, 101, 79, 101, 81, 102, 83, 103, 84, 103, 86, 104, 86, 104, 88, 105, 90, 106, 92, 107, 93, 107, 95, 108, 96, 109, 97, 110, 99, 111, 100, 112, 101, 112, 102, 112, 103, 113, 104, 114, 104, 115, 105, 116, 106, 116, 107, 117, 108, 117, 108, 117, 108, 118, 106, 118, 104, 119, 102, 119, 101, 119, 100, 120, 98, 122, 96, 122, 95, 122, 94, 122, 94, 122, 93, 122, 92, 122, 92, 123, 90, 123, 89, 123, 88, 124, 87, 124, 85, 125, 84, 125, 83, 126, 81, 126, 80, 126, 78, 127, 77, 127, 76, 128, 74, 128, 73, 129, 72, 129, 70, 129, 69, 129, 68, 129, 67, 129, 66, 130, 66, 132, 66, 134, 66, 136, 66, 137, 66, 139, 66, 141, 66, 142, 66, 143, 67, 144, 68, 145, 68, 147, 69, 148, 69, 149, 69, 150, 69, 151, 68, 151, 67, 152, 66, 152, 65, 153, 64, 153, 63, 154, 62, 155, 60, 155, 59, 156, 57, 156, 55, 156, 54, 156, 53, 156, 51, 156, 50, 156, 49, 156, 47, 156, 46, 156, 45, 156, 44, 156, 44, 157, 43, 157, 42, 157, 41, 158, 40, 159, 39, 160, 38, 160, 37, 161, 36, 162, 35, 162, 34, 163, 33, 163, 32, 164, 31, 164, 30, 164, 29, 165, 28, 165, 27, 166, 25, 166, 24, 166, 23, 166, 21, 166, 21, 167, 20, 167, 20, 167, 19, 168, 19, 168, 19, 169, 19, 170, 18, 173, 18, 175, 18, 176, 18, 177, 18, 179, 18, 181, 18, 182, 18, 183, 18, 184, 17, 185, 17, 187, 17, 189, 17, 190, 17, 190, 17, 191, 17, 192, 17, 193, 17, 193, 17, 193, 17, 194, 16, 196, 14, 197, 14, 197, 13, 198, 12, 199, 9, 199, 8, 200, 6, 201, 5, 201, 4, 202, 3, 202, 2, 202, 2, 202, 1, 202, 1, 203, 1, 203, 1, 203, 1, 203, 1, 203, 1, 203, 0, 203, 0, 204, 0, 204, 0, 204, 0, 204, 0
    };
     static int mat8[1000][2] = {
        203, 239, 203, 239, 203, 239, 203, 239, 203, 239, 203, 238, 203, 238, 203, 238, 203, 238, 204, 237, 204, 237, 204, 236, 204, 235, 205, 234, 205, 233, 205, 232, 206, 231, 206, 230, 206, 228, 207, 227, 207, 226, 207, 225, 207, 224, 208, 223, 208, 222, 208, 221, 208, 220, 209, 219, 209, 217, 209, 215, 210, 213, 210, 212, 210, 211, 211, 210, 211, 209, 211, 208, 212, 206, 212, 205, 212, 204, 213, 203, 213, 202, 213, 201, 214, 200, 214, 200, 214, 200, 214, 199, 214, 199, 215, 197, 215, 196, 215, 196, 215, 196, 216, 195, 216, 195, 216, 194, 217, 193, 217, 191, 217, 190, 217, 190, 218, 190, 218, 190, 218, 189, 218, 189, 219, 187, 219, 186, 219, 186, 219, 186, 220, 185, 220, 184, 220, 183, 220, 183, 220, 183, 221, 182, 221, 180, 221, 179, 222, 178, 222, 178, 222, 178, 222, 178, 222, 178, 222, 178, 222, 178, 222, 178, 222, 178, 222, 177, 222, 177, 223, 177, 223, 177, 223, 177, 224, 175, 224, 175, 224, 175, 225, 175, 225, 175, 225, 175, 226, 175, 227, 175, 227, 175, 228, 175, 229, 175, 229, 175, 229, 175, 230, 175, 231, 175, 232, 174, 233, 174, 233, 174, 233, 174, 233, 174, 234, 174, 234, 174, 234, 174, 235, 172, 237, 171, 238, 169, 238, 168, 239, 167, 239, 167, 239, 167, 239, 166, 239, 165, 240, 163, 241, 160, 242, 158, 242, 157, 242, 156, 243, 154, 243, 153, 243, 152, 244, 151, 244, 150, 244, 150, 244, 149, 244, 149, 244, 149, 245, 149, 245, 149, 245, 149, 245, 149, 245, 149, 245, 149, 245, 149, 246, 149, 247, 147, 247, 146, 247, 146, 248, 146, 248, 146, 249, 146, 250, 146, 250, 146, 251, 146, 251, 146, 252, 145, 252, 145, 253, 145, 253, 145, 253, 
        145, 254, 145, 254, 145, 254, 145, 255, 145, 256, 143, 259, 139, 261, 136, 261, 134, 262, 133, 263, 131, 264, 128, 267, 125, 268, 121, 270, 118, 270, 116, 271, 114, 272, 113, 273, 112, 274, 111, 275, 108, 277, 105, 278, 103, 279, 102, 279, 101, 279, 101, 279, 101, 280, 101, 281, 100, 284, 97, 286, 93, 287, 92, 287, 92, 288, 92, 289, 92, 289, 92, 290, 92, 291, 92, 292, 92, 294, 92, 298, 91, 299, 91, 299, 91, 302, 91, 304, 91, 304, 91, 305, 92, 308, 92, 309, 92, 309, 92, 311, 92, 313, 93, 314, 93, 315, 93, 315, 93, 315, 93, 315, 93, 316, 93, 316, 93, 316, 93, 317, 94, 317, 94, 317, 94, 317, 94, 317, 94, 317, 94, 317, 94, 317, 94, 318, 94    };
     static int mat9[1000][2] = {
        0, 93, 0, 93, 0, 93, 0, 93, 0, 93, 1, 93, 1, 93, 1, 93, 2, 93, 3, 93, 3, 93, 4, 93, 5, 93, 6, 93, 8, 93, 9, 93, 10, 93, 10, 93, 11, 93, 12, 93, 13, 93, 13, 93, 14, 93, 15, 93, 16, 93, 17, 93, 18, 94, 19, 94, 20, 94, 20, 94, 21, 94, 22, 94, 22, 94, 23, 94, 24, 94, 24, 94, 25, 94, 25, 94, 26, 95, 27, 95, 28, 95, 29, 96, 30, 96, 30, 96, 30, 97, 30, 98, 30, 98, 31, 99, 31, 100, 31, 101, 32, 102, 32, 103, 32, 104, 33, 105, 33, 105, 33, 105, 34, 106, 34, 106, 34, 106, 35, 106, 36, 107, 37, 107, 38, 107, 39, 107, 39, 108, 40, 108, 41, 108, 41, 109, 42, 109, 43, 109, 44, 109, 44, 110, 44, 110, 45, 110, 46, 110, 47, 110, 48, 110, 49, 111, 50, 111, 51, 111, 51, 111, 52, 111, 52, 111, 53, 111, 54, 112, 55, 112, 56, 112, 57, 113, 58, 113, 59, 113, 60, 113, 61, 114, 61, 114, 61, 114, 62, 114, 63, 114, 64, 115, 65, 115, 66, 115, 66, 115, 67, 115, 68, 115, 68, 116, 69, 116, 69, 116, 70, 116, 71, 116, 71, 116, 72, 117, 73, 117, 73, 117, 74, 
        117, 74, 117, 74, 117, 75, 117, 76, 117, 77, 117, 78, 118, 78, 118, 79, 118, 80, 118, 80, 118, 81, 118, 81, 119, 82, 119, 83, 119, 84, 120, 85, 120, 87, 120, 89, 121, 91, 122, 91, 122, 91, 122, 91, 122, 92, 122, 92, 122, 93, 123, 94, 123, 94, 123, 95, 123, 96, 123, 97, 123, 97, 123, 98, 123, 98, 123, 99, 124, 100, 124, 100, 124, 101, 124, 102, 124, 103, 124, 103, 124, 104, 124, 105, 124, 106, 125, 106, 125, 106, 125, 107, 126, 107, 126, 107, 127, 107, 128, 108, 128, 108, 129, 108, 130, 108, 131, 108, 132, 109, 132, 109, 133, 109, 134, 110, 134, 110, 135, 111, 136, 111, 136, 112, 137, 112, 138, 112, 138, 113, 139, 113, 
        140, 113, 141, 114, 141, 114, 142, 114, 143, 114, 144, 115, 145, 115, 146, 115, 146, 115, 147, 116, 147, 116, 148, 116, 148, 117, 149, 117, 150, 117, 150, 117, 151, 118, 151, 118, 152, 118, 152, 119, 153, 119, 153, 119, 154, 119, 154, 119, 154, 120, 154, 120, 154, 120, 154, 120, 154, 120, 154, 121, 154, 121, 154, 121, 154, 121, 154, 121, 154, 122, 154, 122, 153, 122, 153, 123, 153, 123, 152, 124, 152, 124, 152, 124, 151, 125, 151, 125, 151, 125, 150, 126, 150, 126, 150, 126, 149, 127, 149, 127, 149, 128, 148, 128, 148, 129, 148, 129, 147, 129, 147, 130, 147, 130, 146, 131, 146, 131, 146, 131, 145, 132, 145, 132, 144, 133, 144, 133, 144, 133, 144, 134, 143, 134, 143, 134, 142, 134, 142, 135, 142, 135, 141, 135, 141, 136, 140, 136, 140, 136, 140, 137, 140, 137, 139, 137, 139, 138, 138, 138, 138, 139, 137, 139, 137, 139, 136, 140, 136, 140, 136, 140, 136, 140, 135, 141, 135, 141, 135, 141, 134, 141, 134, 142, 134, 142, 134, 142, 134, 142, 133, 143, 133, 143, 133, 143, 133, 144, 132, 144, 132, 145, 132, 145, 131, 145, 131, 146, 131, 146, 131, 147, 130, 147, 130, 148, 130, 148, 129, 148, 129, 149, 129, 149, 128, 150, 128, 150, 128, 150, 128, 151, 128, 151, 127, 152, 127, 152, 127, 152, 126, 152, 126, 153, 126, 153, 126, 153, 125, 153, 125, 154, 125, 154, 124, 154, 124, 155, 123, 155, 123, 155, 123, 156, 122, 156, 122, 156, 122, 157, 121, 157, 121, 157, 121, 158, 121, 158, 120, 158, 120, 158, 120, 158, 119, 159, 119, 159, 119, 159, 118, 159, 118, 159, 118, 159, 117, 159, 117, 160, 117, 160, 118, 160, 118, 160, 118, 160, 118, 160, 118, 160, 117, 
        161, 117, 161, 117, 161, 116, 161, 116, 162, 116, 162, 115, 162, 115, 162, 114, 163, 114, 163, 113, 163, 113, 163, 112, 163, 112, 163, 112, 163, 112, 163, 112, 163, 112, 163, 112, 163, 112, 163, 112, 163, 112, 163, 112, 163, 112, 163, 112, 163, 112, 163, 112, 163, 111, 163, 111, 163, 111, 163, 111, 164, 110, 164, 110, 164, 109, 165, 108, 165, 107, 165, 107, 166, 106, 166, 106, 166, 105, 166, 105, 166, 104, 166, 104, 166, 103, 167, 103, 167, 102, 167, 101, 167, 101, 167, 100, 167, 99, 167, 99, 167, 98, 167, 97, 167, 97, 167, 96, 167, 96, 168, 95, 168, 94, 168, 94, 168, 93, 169, 93, 169, 92, 169, 92, 169, 91, 169, 91, 170, 90, 170, 89, 170, 89, 170, 88, 170, 88, 170, 87, 170, 86, 171, 86, 171, 85, 171, 84, 171, 84, 171, 83, 171, 83, 172, 82, 172, 82, 172, 81, 172, 81, 172, 80, 172, 79, 172, 79, 173, 78, 173, 77, 173, 77, 173, 76, 173, 76, 173, 75, 173, 75, 173, 74, 173, 74, 174, 73, 174, 73, 174, 72, 174, 72, 174, 71, 175, 70, 
        175, 70, 175, 69, 175, 69, 175, 68, 175, 67, 176, 67, 176, 67, 176, 66, 176, 66, 176, 65, 176, 64, 176, 64, 176, 63, 177, 63, 177, 63, 177, 62, 177, 61, 177, 61, 177, 60, 178, 59, 178, 59, 178, 58, 178, 58, 178, 59, 178, 59, 178, 59, 178, 59, 178, 58, 178, 58, 179, 57, 179, 57, 179, 56, 179, 56, 179, 55, 179, 54, 179, 54, 179, 53, 179, 53, 179, 53, 179, 53, 179, 53, 179, 53, 179, 53, 179, 53, 179, 53, 179, 52, 179, 51, 179, 51, 179, 50, 179, 50, 179, 49, 179, 49, 179, 48, 180, 47, 180, 47, 180, 46, 180, 46, 180, 45, 180, 45, 180, 44, 180, 44, 180, 43, 180, 42, 180, 41, 180, 40, 180, 39, 180, 39, 181, 38, 181, 37, 181, 
        37, 181, 36, 181, 36, 181, 36, 181, 35, 181, 35, 181, 34, 181, 34, 181, 33, 181, 33, 181, 32, 181, 32, 181, 31, 181, 31, 181, 30, 181, 30, 181, 29, 181, 29, 181, 29, 181, 28, 181, 28, 181, 28, 181, 28, 182, 27, 182, 27, 182, 27, 182, 27, 182, 26, 183, 26, 183, 26, 183, 25, 184, 25, 184, 24, 185, 24, 185, 23, 186, 23, 186, 23, 187, 22, 187, 22, 188, 21, 189, 21, 189, 21, 190, 20, 191, 20, 191, 20, 192, 19, 193, 19, 194, 19, 195, 18, 195, 18, 196, 18, 197, 18, 197, 17, 198, 17, 199, 17, 199, 17, 200, 16, 201, 16, 201, 16, 202, 16, 203, 16, 203, 15, 204, 15, 204, 15, 205, 14, 206, 14, 206, 14, 207, 14, 207, 14, 208, 13, 208, 13, 209, 13, 209, 12, 210, 12, 210, 12, 210, 12, 211, 11, 211, 11, 211, 11, 212, 10, 212, 10, 213, 10, 213, 10, 213, 10, 213, 9, 214, 9, 214, 9, 214, 8, 214, 8, 214, 8, 215, 7, 215, 7, 215, 7, 215, 6, 215, 6, 215, 6, 216, 5, 216, 5, 216, 5, 216, 5, 216, 4, 217, 4, 217, 4, 217, 4, 217, 3, 218, 3, 218, 2, 219, 2, 219, 2, 219, 1, 219, 1, 219, 1, 220, 1, 220, 0, 220, 0, 220, 0
     };
     static int mat10[1000][2] = {
         220, 238, 220, 238, 221, 237, 221, 236, 221, 236, 221, 235, 222, 235, 222, 234, 223, 234, 223, 234, 224, 233, 224, 233, 225, 231, 225, 231, 226, 230, 226, 229, 226, 229, 226, 228, 226, 227, 227, 227, 227, 226, 227, 225, 227, 224, 228, 224, 228, 223, 230, 222, 231, 221, 231, 220, 232, 220, 232, 219, 233, 219, 234, 218, 235, 217, 236, 216, 236, 215, 237, 215, 237, 214, 238, 213, 239, 213, 241, 211, 242, 210, 242, 209, 242, 209, 243, 208, 244, 206, 245, 204, 245, 203, 246, 202, 246, 200, 246, 199, 246, 198, 246, 198, 246, 198, 246, 197, 246, 196, 246, 195, 246, 193, 247, 191, 247, 189, 247, 188, 247, 186, 248, 185, 248, 183, 248, 181, 248, 180, 248, 179, 248, 179, 249, 179, 251, 178, 252, 178, 254, 178, 254, 178, 254, 178, 255, 178, 255, 177, 256, 177, 257, 176, 257, 175, 258, 175, 258, 175, 259, 174, 260, 173, 261, 171, 262, 169, 263, 168, 263, 167, 263, 167, 264, 167, 264, 167, 265, 165, 266, 164, 266, 162, 267, 160, 268, 159, 268, 158, 269, 156, 269, 155, 269, 154, 270, 152, 270, 152, 271, 151, 271, 150, 272, 148, 273, 148, 274, 147, 275, 147, 278, 147, 280, 147, 282, 147, 283, 147, 286, 147, 287, 147, 287, 147, 288, 147, 290, 147, 291, 147, 293, 147, 294, 147, 295, 147, 296, 147, 298, 147, 299, 147, 300, 147, 302, 147, 303, 147, 304, 147, 305, 147, 306, 147, 308, 147, 310, 147, 312, 147, 312, 147, 313, 147, 314, 147, 315, 147, 315, 147, 316, 147, 317, 147, 317, 147, 318, 147, 319, 147, 319, 147, 319, 147, 319, 147
    };
     static int mat11[1000][2] = {
        0, 148, 0, 148, 0, 148, 0, 148, 0, 148, 0, 148, 0, 148, 1, 148, 1, 148, 1, 148, 1, 148, 2, 148, 3, 148, 3, 148, 4, 148, 4, 148, 4, 148, 5, 148, 5, 148, 5, 148, 6, 147, 7, 147, 7, 147, 7, 147, 8, 147, 8, 147, 9, 147, 10, 147, 10, 147, 11, 147, 11, 147, 12, 147, 12, 147, 12, 147, 13, 147, 13, 147, 13, 147, 13, 147, 14, 147, 14, 147, 14, 147, 15, 147, 15, 147, 15, 147, 16, 147, 17, 147, 17, 146, 17, 146, 17, 146, 18, 146, 18, 146, 18, 145, 18, 145, 19, 144, 19, 144, 19, 143, 20, 143, 20, 142, 20, 142, 20, 142, 21, 141, 22, 139, 22, 139, 23, 138, 24, 137, 25, 136, 25, 136, 25, 135, 25, 135, 25, 135, 25, 135, 25, 135, 25, 135, 26, 135, 26, 135, 26, 134, 26, 134, 26, 134, 26, 134, 26, 134, 26, 133, 27, 132, 28, 131, 28, 131, 28, 131, 28, 130, 28, 130, 29, 128, 30, 127, 30, 127, 30, 127, 30, 127, 30, 126, 30, 126, 30, 126, 30, 126, 30, 126, 30, 126, 30, 126, 30, 126, 31, 126, 31, 126, 31, 126, 32, 125, 32, 123, 33, 123, 33, 123, 33, 123, 33, 122, 34, 119, 34, 117, 34, 117, 34, 117, 34, 117, 35, 117, 35, 117, 35, 117, 35, 117, 35, 117, 35, 115, 35, 115, 35, 115, 36, 114, 36, 112, 37, 110, 37, 109, 37, 109, 37, 109, 38, 108, 38, 106, 39, 104, 39, 103, 39, 103, 40, 102, 40, 100, 41, 99, 41, 99, 41, 99, 41, 99, 41, 98, 42, 98, 42, 97, 43, 96, 
        43, 95, 44, 94, 44, 94, 44, 93, 46, 91, 47, 89, 47, 88, 47, 88, 47, 88, 48, 87, 48, 87, 48, 87, 48, 87, 48, 86, 49, 85, 49, 84, 49, 84, 50, 83, 50, 82, 51, 81, 52, 80, 52, 79, 52, 79, 52, 79, 52, 79, 53, 78, 53, 76, 53, 76, 53, 76, 53, 76, 53, 76, 53, 81, 53, 81, 53, 81, 53, 81, 53, 80, 53, 80, 53, 79, 54, 79, 54, 78, 54, 77, 55, 77, 55, 77, 55, 76, 56, 76, 56, 75, 56, 75, 56, 74, 56, 74, 57, 74, 57, 74, 57, 74, 57, 74, 58, 73, 59, 73, 59, 73, 59, 73, 60, 73, 60, 73, 60, 73, 61, 73, 61, 73, 61, 73, 62, 74, 62, 74, 62, 74, 63, 74, 64, 74, 64, 75, 65, 75, 65, 75, 65, 75, 66, 76, 66, 76, 66, 76, 67, 76, 67, 76, 67, 77, 67, 77, 67, 77, 68, 78, 68, 78, 68, 78, 68, 78, 68, 78, 68, 78, 68, 78, 69, 78, 69, 78, 69, 78, 69, 78, 69, 77, 69, 77, 70, 77, 70, 77, 70, 76, 70, 76, 70, 76, 70, 76, 70, 75, 70, 75, 71, 75, 71, 74, 71, 74, 71, 73, 71, 72, 71, 72, 72, 72, 72, 71, 72, 71, 72, 71, 72, 71, 72, 71, 72, 71, 72, 71, 72, 71, 72, 71, 72, 71, 72, 71, 72, 71, 72, 71, 72, 71, 72, 70, 72, 70, 72, 70, 72, 70, 72, 70, 72, 69, 73, 68, 73, 67, 73, 66, 73, 66, 73, 65, 74, 64, 74, 63, 75, 61, 75, 59, 75, 58, 76, 57, 76, 56, 76, 55, 77, 54, 77, 52, 78, 49, 79, 46, 79, 43, 80, 42, 80, 42, 80, 42, 80, 41, 80, 41, 80, 41, 80, 40, 81, 40, 81, 39, 81, 38, 81, 
        38, 82, 37, 82, 36, 83, 34, 83, 32, 84, 31, 84, 31, 84, 31, 84, 31, 84, 30, 85, 29, 85, 28, 85, 27, 86, 26, 86, 26, 86, 26, 86, 26, 86, 26, 86, 26, 86, 25, 86, 25, 87, 25, 87, 25, 88, 25, 89, 25, 90, 25, 90, 25, 91, 25, 91, 25, 91, 25, 91, 25, 91, 25, 91, 25, 92, 25, 92, 25, 93, 25, 94, 25, 95, 25, 95, 25, 96, 26, 96, 26, 96, 26, 96, 26, 97, 26, 97, 26, 97, 26, 98, 27, 98, 27, 99, 27, 100, 28, 101, 28, 102, 28, 102, 28, 103, 28, 103, 28, 104, 29, 104, 29, 105, 29, 105, 29, 106, 29, 106, 29, 106, 29, 106, 29, 106, 29, 107, 29, 107, 29, 108, 28, 109, 28, 109, 28, 109, 28, 110, 27, 110, 27, 111, 27, 112, 26, 112, 26, 112, 26, 113, 25, 113, 25, 113, 25, 113, 24, 113, 24, 114, 23, 114, 21, 115, 20, 115, 20, 115, 19, 116, 18, 116, 17, 117, 15, 118, 13, 118, 12, 118, 12, 118, 11, 119, 10, 119, 9, 119, 7, 119, 6, 120, 5, 120, 3, 120, 2, 120, 2, 120, 1, 120, 1, 120, 0, 120, 0, 120, 0, 120, 0, 120, 0, 120, 0, 120, 0, 120, 0, 120, 0, 120, 0, 120, 0    
    };
    static int mat12[1000][2] = {
    };
     static int mat13[1000][2] = {
        121, 239, 121, 239, 121, 238, 121, 237, 121, 236, 121, 236, 121, 235, 122, 234, 122, 233, 122, 232, 123, 231, 123, 230, 123, 230, 123, 229, 123, 227, 123, 226, 124, 225, 124, 223, 124, 222, 125, 220, 125, 219, 125, 218, 125, 218, 125, 218, 125, 217, 125, 215, 125, 214, 126, 212, 126, 211, 126, 210, 126, 209, 126, 207, 126, 206, 127, 205, 127, 203, 127, 202, 127, 201, 127, 200, 128, 199, 128, 197, 128, 196, 128, 196, 128, 195, 128, 194, 128, 193, 129, 192, 129, 192, 129, 191, 129, 191, 129, 190, 130, 187, 130, 185, 130, 184, 130, 184, 130, 184, 131, 183, 131, 181, 131, 179, 131, 178, 131, 178, 131, 178, 132, 178, 132, 177, 132, 176, 132, 176, 132, 175, 132, 175, 132, 175, 132, 174, 133, 172, 133, 170, 133, 169, 133, 169, 133, 169, 133, 169, 133, 168, 133, 168, 133, 168, 134, 168, 134, 166, 134, 165, 134, 165, 134, 165, 134, 164, 135, 163, 135, 160, 136, 159, 136, 159, 136, 159, 136, 159, 136, 158, 136, 156, 136, 156, 136, 155, 136, 154, 137, 152, 137, 151, 137, 151, 137, 151, 137, 150, 138, 149, 138, 148, 138, 146, 138, 145, 139, 145, 139, 144, 139, 143, 139, 143, 139, 141, 139, 140, 139, 138, 140, 137, 140, 136, 140, 135, 140, 135, 141, 134, 141, 134, 141, 134, 141, 133, 141, 133, 141, 133, 141, 133, 142, 133, 142, 133, 143, 133, 144, 133, 145, 133, 146, 133, 146, 133, 146, 133, 147, 134, 147, 134, 147, 134, 147, 134, 148, 135, 149, 135, 149, 135, 150, 135, 150, 134, 151, 134, 151, 133, 151, 132, 151, 131, 151, 129, 152, 128, 152, 127, 152, 127, 152, 127, 152, 126, 152, 124, 153, 122, 153, 121, 153, 120, 153, 120, 153, 120, 153, 119, 153, 
        117, 153, 116, 153, 116, 154, 116, 154, 116, 154, 115, 154, 114, 154, 113, 154, 111, 154, 110, 154, 110, 154, 110, 155, 109, 155, 108, 155, 106, 155, 105, 156, 105, 156, 104, 156, 104, 156, 104, 156, 103, 156, 101, 157, 100, 157, 99, 157, 98, 157, 98, 157, 98, 157, 98, 157, 98, 157, 98, 157, 98, 157, 98, 157, 98, 158, 98, 159, 98, 160, 98, 160, 98, 161, 98, 162, 98, 163, 98, 164, 98, 165, 98, 166, 98, 166, 98, 166, 98, 167, 98, 167, 97, 168, 97, 169, 97, 169, 96, 169, 96, 169, 96, 169, 96, 169, 95, 170, 94, 170, 93, 171, 92, 171, 91, 172, 90, 172, 89, 172, 89, 172, 88, 172, 87, 173, 86, 173, 85, 173, 85, 173, 84, 173, 
        83, 174, 82, 174, 81, 175, 80, 175, 79, 175, 78, 175, 77, 175, 77, 175, 77, 176, 76, 176, 74, 177, 73, 177, 73, 177, 73, 177, 72, 178, 71, 178, 70, 179, 69, 179, 68, 179, 67, 179, 66, 179, 65, 180, 64, 180, 63, 180, 61, 181, 60, 181, 59, 181, 58, 181, 58, 181, 57, 182, 56, 182, 55, 182, 53, 183, 52, 183, 50, 184, 48, 184, 47, 184, 47, 184, 46, 184, 46, 185, 45, 185, 43, 185, 43, 185, 43, 185, 42, 186, 42, 186, 42, 186, 42, 186, 42, 186, 42, 186, 41, 186, 40, 187, 38, 187, 37, 187, 37, 187, 37, 187, 37, 188, 36, 188, 35, 188, 34, 189, 33, 189, 33, 189, 32, 189, 32, 189, 32, 189, 31, 190, 31, 190, 30, 190, 30, 190, 28, 191, 27, 191, 27, 191, 26, 191, 26, 191, 26, 191, 26, 191, 25, 192, 24, 192, 23, 192, 23, 193, 23, 193, 23, 193, 23, 194, 23, 194, 23, 195, 23, 195, 23, 195, 23, 195, 23, 196, 23, 196, 24, 196, 24, 197, 25, 197, 26, 197, 26, 197, 27, 198, 28, 198, 28, 198, 28, 198, 28, 200, 28, 201, 28, 201, 27, 202, 26, 202, 26, 203, 26, 204, 26, 205, 27, 206, 27, 207, 28, 208, 28, 209, 29, 210, 29, 210, 29, 211, 29, 211, 29, 212, 28, 212, 27, 213, 26, 213, 26, 213, 25, 213, 25, 213, 24, 213, 23, 213, 22, 213, 20, 213, 20, 213, 20, 213, 20, 213, 19, 213, 19, 213, 18, 213, 17, 213, 14, 213, 13, 213, 13, 213, 13, 213, 13, 213, 12, 213, 11, 213, 9, 213, 8, 213, 8, 213, 7, 213, 6, 213, 4, 213, 3, 213, 3, 213, 3, 213, 2, 213, 2, 213, 1, 214, 0, 214, 0
    };
     static int mat14[1000][2] = {
        215, 238, 215, 238, 215, 238, 216, 237, 217, 236, 217, 235, 218, 233, 218, 232, 219, 232, 219, 231, 220, 230, 221, 229, 221, 228, 221, 228, 222, 227, 223, 226, 223, 225, 223, 225, 224, 224, 224, 223, 225, 223, 226, 222, 226, 221, 228, 219, 228, 218, 228, 218, 229, 217, 229, 215, 230, 214, 230, 214, 230, 214, 230, 213, 231, 212, 231, 210, 232, 209, 232, 208, 232, 208, 232, 208, 232, 207, 233, 207, 233, 206, 234, 204, 234, 203, 234, 202, 234, 202, 234, 201, 234, 199, 235, 197, 235, 196, 235, 196, 235, 195, 235, 194, 235, 192, 235, 191, 236, 191, 236, 191, 236, 190, 236, 190, 236, 188, 236, 186, 236, 185, 236, 184, 236, 182, 237, 180, 237, 179, 237, 178, 238, 177, 238, 175, 238, 174, 238, 173, 238, 172, 238, 171, 238, 171, 238, 171, 238, 170, 238, 168, 238, 167, 239, 166, 239, 166, 239, 165, 239, 164, 239, 164, 239, 163, 239, 161, 239, 160, 239, 159, 239, 158, 239, 157, 239, 156, 239, 155, 239, 154, 239, 153, 239, 153, 239, 153, 239, 153, 239, 152, 239, 152, 239, 152, 239, 152, 239, 151, 240, 150, 240, 149, 240, 148, 240, 147, 240, 147, 241, 147, 241, 147, 241, 146, 241, 146, 241, 146, 242, 146, 243, 145, 243, 145, 243, 145, 244, 144, 245, 143, 246, 143, 246, 142, 247, 142, 248, 141, 249, 140, 249, 140, 250, 140, 251, 139, 252, 138, 253, 138, 253, 137, 254, 137, 255, 135, 256, 134, 256, 133, 257, 132, 257, 131, 258, 130, 258, 129, 258, 129, 258, 128, 258, 128, 259, 127, 259, 127, 259, 126, 259, 125, 260, 124, 260, 123, 260, 122, 260, 122, 260, 121, 261, 120, 261, 118, 261, 117, 261, 115, 262, 114, 262, 113, 262, 113, 262, 113, 263, 112, 263, 
        111, 263, 111, 263, 110, 264, 110, 264, 108, 265, 108, 265, 106, 265, 106, 266, 105, 266, 103, 266, 102, 267, 102, 267, 101, 267, 101, 267, 100, 267, 99, 268, 98, 268, 98, 268, 96, 268, 95, 268, 94, 268, 93, 268, 92, 268, 92, 268, 92, 269, 91, 269, 90, 270, 89, 270, 88, 270, 87, 271, 86, 271, 86, 271, 86, 271, 86, 272, 85, 273, 85, 273, 84, 273, 84, 274, 84, 275, 84, 275, 84, 276, 84, 276, 84, 277, 83, 278, 83, 278, 83, 278, 83, 279, 82, 280, 82, 280, 81, 280, 81, 280, 81, 281, 81, 282, 82, 283, 83, 283, 84, 283, 84, 284, 84, 284, 83, 285, 82, 285, 81, 285, 81, 286, 80, 286, 79, 286, 79, 287, 79, 288, 79, 288, 79, 288, 79, 289, 79, 289, 79, 290, 80, 291, 81, 292, 82, 293, 84, 293, 86, 294, 88, 294, 88, 294, 88, 294, 88, 294, 88, 294, 89, 294, 89, 294, 90, 294, 91, 294, 92, 294, 93, 295, 94, 295, 94, 295, 95, 296, 97, 296, 98, 296, 99, 296, 99, 296, 100, 296, 100, 297, 101, 297, 102, 297, 103, 297, 103, 298, 104, 298, 105, 298, 106, 299, 107, 299, 108, 299, 108, 299, 108, 299, 108, 299, 109, 299, 110, 300, 111, 300, 111, 300, 111, 300, 111, 300, 112, 300, 114, 301, 116, 301, 117, 301, 118, 302, 120, 302, 121, 302, 121, 302, 121, 302, 122, 303, 123, 303, 125, 304, 126, 304, 127, 304, 128, 305, 129, 305, 130, 306, 131, 306, 132, 306, 132, 306, 132, 306, 133, 306, 134, 307, 135, 308, 136, 308, 137, 308, 138, 308, 138, 309, 139, 309, 140, 310, 142, 311, 143, 311, 143, 311, 143, 311, 143, 311, 144, 311, 144, 311, 144, 311, 144, 311, 144, 311, 144, 311, 144, 312, 145, 312, 145, 312, 145, 312, 145, 312, 145, 312, 145, 312, 145, 312, 145, 312, 145, 312, 145, 313, 145, 313, 145, 314, 145, 315, 145, 316, 145, 317, 145, 317, 145, 318, 145, 319, 145, 319, 145, 319, 145, 319, 145
    };
     static int mat15[1000][2] = {
        0, 142, 0, 142, 0, 142, 0, 142, 0, 142, 0, 142, 2, 142, 3, 142, 4, 141, 5, 141, 5, 141, 5, 141, 5, 141, 7, 141, 7, 141, 9, 141, 10, 141, 10, 141, 10, 141, 10, 141, 10, 141, 10, 141, 11, 140, 12, 139, 12, 139, 13, 138, 13, 137, 13, 136, 14, 135, 14, 133, 14, 132, 15, 131, 15, 131, 15, 130, 16, 129, 17, 127, 18, 126, 18, 125, 18, 124, 19, 123, 19, 122, 
        21, 120, 22, 119, 22, 118, 23, 117, 24, 115, 25, 114, 26, 113, 26, 112, 27, 110, 28, 109, 28, 107, 29, 107, 29, 106, 30, 104, 30, 102, 31, 101, 31, 100, 32, 99, 32, 97, 33, 96, 33, 94, 34, 93, 34, 91, 35, 90, 36, 88, 36, 86, 37, 85, 37, 84, 38, 83, 38, 82, 39, 81, 40, 79, 41, 77, 42, 75, 43, 73, 43, 72, 44, 72, 45, 70, 45, 69, 46, 68, 46, 68, 46, 68, 
        47, 67, 48, 65, 48, 64, 48, 64, 48, 64, 49, 64, 49, 63, 50, 62, 50, 62, 50, 62, 51, 62, 52, 62, 53, 62, 54, 62, 55, 61, 56, 61, 56, 61, 57, 61, 59, 61, 62, 61, 65, 61, 66, 61, 66, 61, 66, 61, 67, 60, 72, 60, 74, 60, 74, 60, 74, 60, 74, 60, 74, 60, 75, 60, 76, 60, 77, 60, 77, 60, 77, 60, 77, 60, 77, 60, 78, 60, 79, 60, 80, 60, 81, 60, 82, 60, 84, 60, 85, 60, 85, 60, 85, 60, 86, 60, 88, 59, 89, 59, 89, 59, 89, 59, 89, 59, 92, 59, 94, 59, 96, 59, 96, 59, 96, 59, 96, 59, 97, 59, 100, 59, 100, 59, 100, 59, 101, 58, 102, 58, 104, 58, 106, 58, 107, 58, 107, 58, 108, 58, 109, 57, 111, 57, 113, 57, 114, 57, 114, 57, 114, 57, 114, 57, 115, 57, 116, 57, 116, 57, 117, 57, 119, 56, 120, 56, 120, 56, 120, 56, 120, 56, 123, 56, 127, 56, 129, 56, 129, 56, 129, 56, 129, 56, 129, 56, 129, 56, 129, 56, 131, 56, 131, 56, 131, 56, 132, 56, 134, 56, 136, 56, 136, 56, 136, 56, 136, 56, 136, 56, 137, 56, 138, 56, 139, 56, 141, 56, 142, 55, 142, 55, 142, 55, 143, 55, 143, 55, 145, 55, 145, 55, 146, 55, 146, 55, 146, 55, 147, 55, 148, 55, 150, 54, 151, 54, 151, 54, 151, 54, 152, 54, 155, 54, 157, 54, 159, 53, 159, 53, 159, 53, 160, 53, 162, 53, 162, 53, 163, 53, 164, 53, 167, 52, 169, 52, 169, 52, 170, 52, 172, 52, 174, 51, 176, 51, 177, 51, 178, 51, 178, 51, 180, 51, 181, 50, 184, 50, 185, 50, 185, 50, 186, 50, 188, 49, 189, 49, 191, 49, 192, 49, 192, 49, 192, 49, 192, 49, 192, 49, 193, 48, 193, 48, 193, 48, 193, 
        48, 193, 48, 193, 48, 194, 48, 194, 48, 194, 48, 194, 48, 194, 48, 195, 48, 195, 48, 195, 48, 195, 48, 195, 48, 195, 48, 195, 46, 195, 45, 195, 44, 195, 44, 195, 44, 195, 42, 196, 41, 196, 39, 196, 39, 196, 38, 196, 37, 197, 36, 197, 35, 197, 33, 197, 33, 197, 32, 197, 30, 197, 30, 197, 30, 197, 29, 197, 29, 197, 28, 197, 27, 198, 25, 198, 22, 198, 22, 198, 22, 198, 21, 198, 20, 198, 20, 198, 19, 198, 19, 198, 18, 198, 16, 198, 13, 198, 12, 198, 12, 198, 12, 198, 11, 198, 10, 198, 10, 198, 9, 198, 8, 198, 7, 198, 6, 198, 5, 198, 5, 198, 3, 198, 2, 198, 0, 198, 0, 198, 0, 198, 0, 198, 0, 198, 0, 198, 0    
        };

    //declaring matrix pointers that will be returned to be the adress of each respective matrix
    matrix1 = &mat1[0][0];
    matrix2 = &mat2[0][0];
    matrix3 = &mat3[0][0];
    matrix4 = &mat4[0][0];
    matrix5 = &mat5[0][0];
    matrix6 = &mat6[0][0];
    matrix7 = &mat7[0][0];
    matrix8 = &mat8[0][0];
    matrix9 = &mat9[0][0];
    matrix10 = &mat10[0][0];
    matrix11 = &mat11[0][0];
    matrix12 = &mat12[0][0];
    matrix13 = &mat13[0][0];
    matrix14 = &mat14[0][0];
    matrix15 = &mat15[0][0];

    //big switch case that actually returns the matrix collision points depending on which map the maptracker function decides it should be on
    switch (map) {
    case 1:
    return(matrix1);
    break;
    case 2:
    return(matrix2);
    break;
    case 3:
    return(matrix3);
    break;
    case 4:
    return(matrix4);
    break;
    case 5:
    return(matrix5);
    break;
    case 6:
    return(matrix6);
    break;
    case 7:
    return(matrix7);
    break;
    case 8:
    return(matrix8);
    break;
    case 9:
    return(matrix9);
    break;
    case 10:
    return(matrix10);
    break;    
    case 11:
    return(matrix11);
    break;
    case 12:
    return(matrix12);
    break;
    case 13:
    return(matrix13);
    break;
    case 14:
    return(matrix14);
    break;
    case 15:
    return(matrix15);
    break;

}

}
